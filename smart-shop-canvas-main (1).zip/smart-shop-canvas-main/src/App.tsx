
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@radix-ui/react-tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Preferences from "./pages/Preferences";
import ContactUs from "./pages/ContactUs";
import Rewards from "./pages/Rewards";
import SavedShops from "./pages/SavedShops";
import ShopDetail from "./pages/ShopDetail";
import BottomNavigation from "./components/layout/BottomNavigation";
import { useEffect, useState } from "react";

const queryClient = new QueryClient();

const AppRoutes = () => {
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState<boolean | null>(null);
  
  useEffect(() => {
    // Check if user has completed onboarding
    const onboardingStatus = localStorage.getItem("onboardingCompleted") === "true";
    setHasCompletedOnboarding(onboardingStatus);
  }, []);

  if (hasCompletedOnboarding === null) {
    // Still loading
    return null;
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="w-full"
      >
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/preferences" element={<Preferences />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/rewards" element={<Rewards />} />
          <Route path="/saved-shops" element={<SavedShops />} />
          <Route path="/shop/:shopId" element={<ShopDetail />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        
        {/* Only show bottom navigation if onboarding is completed */}
        {hasCompletedOnboarding && <BottomNavigation />}
      </motion.div>
    </AnimatePresence>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
