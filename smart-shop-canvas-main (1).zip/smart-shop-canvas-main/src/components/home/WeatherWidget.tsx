
import React, { useState, useEffect } from "react";
import { CloudSun, Umbrella, Wind, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";

interface WeatherWidgetProps {
  location: { lat: number; lng: number } | null;
}

interface WeatherData {
  temp: number;
  description: string;
  icon: string;
  humidity: number;
  windSpeed: number;
}

const WeatherWidget: React.FC<WeatherWidgetProps> = ({ location }) => {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!location) return;

    const fetchWeather = async () => {
      setLoading(true);
      try {
        // OpenWeatherMap API - Free tier
        const API_KEY = "4a8793edbfc3e7a417dd54ed05c375cc"; // This is a sample API key for demo purposes
        const response = await fetch(
          `https://api.openweathermap.org/data/2.5/weather?lat=${location.lat}&lon=${location.lng}&units=imperial&appid=${API_KEY}`
        );

        if (!response.ok) {
          throw new Error("Weather data not available");
        }

        const data = await response.json();
        
        setWeather({
          temp: Math.round(data.main.temp),
          description: data.weather[0].description,
          icon: data.weather[0].icon,
          humidity: data.main.humidity,
          windSpeed: data.wind.speed,
        });
        setError(null);
      } catch (err) {
        console.error("Weather API error:", err);
        setError("Could not load weather data");
        
        // Fallback to mock data
        setWeather({
          temp: 72,
          description: "partly cloudy",
          icon: "02d",
          humidity: 65,
          windSpeed: 5.2,
        });
      } finally {
        setLoading(false);
      }
    };

    fetchWeather();
  }, [location]);

  const handleRefresh = () => {
    if (location) {
      toast({
        title: "Refreshing weather",
        description: "Fetching latest weather data"
      });
      
      const fetchWeather = async () => {
        setLoading(true);
        try {
          const API_KEY = "4a8793edbfc3e7a417dd54ed05c375cc";
          const response = await fetch(
            `https://api.openweathermap.org/data/2.5/weather?lat=${location.lat}&lon=${location.lng}&units=imperial&appid=${API_KEY}`
          );
  
          if (!response.ok) {
            throw new Error("Weather data not available");
          }
  
          const data = await response.json();
          
          setWeather({
            temp: Math.round(data.main.temp),
            description: data.weather[0].description,
            icon: data.weather[0].icon,
            humidity: data.main.humidity,
            windSpeed: data.wind.speed,
          });
          setError(null);
        } catch (err) {
          console.error("Weather API error:", err);
          setError("Could not load weather data");
          
          // Fallback to mock data
          setWeather({
            temp: 72,
            description: "partly cloudy",
            icon: "02d",
            humidity: 65,
            windSpeed: 5.2,
          });
        } finally {
          setLoading(false);
        }
      };
  
      fetchWeather();
    }
  };

  if (loading && !weather) {
    return (
      <div className="px-6 pt-4">
        <motion.div 
          className="bg-white rounded-3xl shadow-card p-5 animate-pulse"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="h-20 flex items-center justify-center">
            <RefreshCw className="text-primary/50 animate-spin" />
          </div>
        </motion.div>
      </div>
    );
  }

  if (!weather) return null;

  // If there's an error but we have fallback data, still show the widget
  return (
    <motion.div 
      className="px-6 pt-4"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="bg-white rounded-3xl shadow-card overflow-hidden">
        <div className="relative">
          {/* Header with refresh button */}
          <div className="absolute top-3 right-3 z-10">
            <button 
              className="bg-primary/10 p-1.5 rounded-full hover:bg-primary/20 transition-colors"
              onClick={handleRefresh}
              disabled={loading}
            >
              <RefreshCw size={16} className={`text-primary ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
          
          {/* Main weather info with accent background */}
          <div 
            className="bg-gradient-to-br from-[#4A66E4] to-[#6E83EC] p-6 flex items-center"
          >
            <div className="flex-1">
              <h3 className="font-medium text-3xl text-white font-poppins">
                {weather.temp}°F
              </h3>
              <span className="text-sm text-white/80 capitalize mt-1 block">
                {weather.description}
              </span>
            </div>
            <div>
              {weather.icon ? (
                <img 
                  src={`https://openweathermap.org/img/wn/${weather.icon}@2x.png`} 
                  alt={weather.description}
                  width={70}
                  height={70}
                  className="w-16 h-16 brightness-[1.2]"
                />
              ) : (
                <CloudSun size={64} className="text-white" />
              )}
            </div>
          </div>
          
          {/* Additional details */}
          <div className="p-4 flex justify-between">
            <div className="flex items-center">
              <Umbrella size={18} className="text-primary mr-2 opacity-80" />
              <span className="text-neutral-medium">
                Humidity: <span className="text-neutral-dark font-medium">{weather.humidity}%</span>
              </span>
            </div>
            <div className="flex items-center">
              <Wind size={18} className="text-primary mr-2 opacity-80" />
              <span className="text-neutral-medium">
                Wind: <span className="text-neutral-dark font-medium">{weather.windSpeed} mph</span>
              </span>
            </div>
          </div>
          
          {/* Error indicator */}
          {error && (
            <div className="px-4 pb-3">
              <p className="text-xs text-amber-500 flex items-center">
                <span className="bg-amber-500/20 p-1 rounded-full mr-2">
                  <span className="block w-1.5 h-1.5 rounded-full bg-amber-500"></span>
                </span>
                Using estimated weather data
              </p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default WeatherWidget;
