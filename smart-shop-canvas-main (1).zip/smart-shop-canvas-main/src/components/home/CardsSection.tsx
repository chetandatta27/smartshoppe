
import React from "react";
import { motion } from "framer-motion";
import CardCarousel from "../cards/CardCarousel";
import { CardOffer } from "@/components/shops/ShopTypes";

interface CardsSectionProps {
  showPersonalized: boolean;
  personalizedCards: CardOffer[];
  recommendedCards: CardOffer[];
  onTogglePersonalized: (show: boolean) => void;
}

const CardsSection: React.FC<CardsSectionProps> = ({
  showPersonalized,
  personalizedCards,
  recommendedCards,
  onTogglePersonalized,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.4, duration: 0.5 }}
      className="mt-8 mb-8 px-4"
    >
      <CardCarousel
        cards={showPersonalized ? personalizedCards : recommendedCards}
        title="Recommended Cards"
        description="Based on popular shops near you"
        showPersonalizedToggle={true}
        onTogglePersonalized={onTogglePersonalized}
      />
    </motion.div>
  );
};

export default CardsSection;
