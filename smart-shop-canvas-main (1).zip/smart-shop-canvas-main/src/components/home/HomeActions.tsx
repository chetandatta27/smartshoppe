
import React from "react";
import { motion } from "framer-motion";
import { Settings, MessageCircle, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

interface HomeActionsProps {
  handleViewPreferences: () => void;
  handleShowMap: () => void;
  navigateToRewards: () => void;
  navigateToSavedShops: () => void;
}

const HomeActions: React.FC<HomeActionsProps> = ({
  handleViewPreferences,
  handleShowMap,
  navigateToRewards,
  navigateToSavedShops,
}) => {
  return (
    <div className="px-6 mt-8 mb-24">
      <div className="grid grid-cols-3 gap-6 mb-8">
        <motion.div 
          className="bg-white rounded-2xl shadow-soft p-4 flex flex-col items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.3 }}
          onClick={handleViewPreferences}
        >
          <div className="bg-secondary rounded-full p-3 mb-3">
            <Settings size={20} className="text-primary" />
          </div>
          <span className="text-xs text-center font-medium">Compare Cards</span>
        </motion.div>
        
        <motion.div 
          className="bg-white rounded-2xl shadow-soft p-4 flex flex-col items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6, duration: 0.3 }}
          onClick={navigateToRewards}
        >
          <div className="bg-secondary rounded-full p-3 mb-3">
            <MessageCircle size={20} className="text-primary" />
          </div>
          <span className="text-xs text-center font-medium">My Rewards</span>
        </motion.div>
        
        <motion.div 
          className="bg-white rounded-2xl shadow-soft p-4 flex flex-col items-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.7, duration: 0.3 }}
          onClick={navigateToSavedShops}
        >
          <div className="bg-secondary rounded-full p-3 mb-3">
            <MapPin size={20} className="text-primary" />
          </div>
          <span className="text-xs text-center font-medium">Saved Shops</span>
        </motion.div>
      </div>
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8, duration: 0.3 }}
        className="mb-4"
      >
        <Button 
          className="w-full flex items-center justify-center gap-2 py-6 rounded-2xl"
          onClick={handleShowMap}
        >
          <MapPin size={20} />
          <span>Show Nearby Offers on Map</span>
        </Button>
      </motion.div>
    </div>
  );
};

export default HomeActions;
