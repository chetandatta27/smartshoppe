
import React from "react";
import { motion } from "framer-motion";
import { Bell, User } from "lucide-react";
import SearchBox from "../search/SearchBox";

interface HomeHeaderProps {
  unreadCount: number;
  handleToggleNotifications: () => void;
  handleSearch: (query: string) => void;
  handleLocationSearch: () => void;
}

const HomeHeader: React.FC<HomeHeaderProps> = ({
  unreadCount,
  handleToggleNotifications,
  handleSearch,
  handleLocationSearch,
}) => {
  return (
    <div className="sticky top-0 z-10 bg-primary shadow-md">
      <div className="pt-12 pb-4 px-6">
        <div className="flex justify-between items-center mb-4">
          <motion.h1 
            className="text-xl font-bold text-white font-poppins"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            ShopSmart
          </motion.h1>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center text-white">
              <User size={18} className="mr-1" />
              <span className="text-sm font-medium">Raghu Datta</span>
            </div>
            
            <button 
              className="text-white relative"
              onClick={handleToggleNotifications}
            >
              <Bell size={22} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-4 h-4 flex items-center justify-center rounded-full">
                  {unreadCount}
                </span>
              )}
            </button>
          </div>
        </div>
        
        <SearchBox 
          onSearch={handleSearch} 
          onLocationSearch={handleLocationSearch} 
          placeholder="Search by shop name or address"
        />
      </div>
    </div>
  );
};

export default HomeHeader;
