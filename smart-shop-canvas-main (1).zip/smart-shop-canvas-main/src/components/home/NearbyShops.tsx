
import React, { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Store, Coffee, Utensils, ShoppingCart } from "lucide-react";
import { motion } from "framer-motion";

interface NearbyShopsProps {
  location: {
    lat: number;
    lng: number;
  };
}

interface Place {
  id: string;
  name: string;
  type: string;
  distance: string;
  address: string;
  icon: React.ElementType;
}

const NearbyShops: React.FC<NearbyShopsProps> = ({ location }) => {
  const [places, setPlaces] = useState<Place[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // In a real app, we would call a Places API here
    // For this demo, we'll use mock data but simulate a real API call
    const fetchNearbyPlaces = async () => {
      setLoading(true);
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock data with location-based names
      const mockPlaces: Place[] = [
        {
          id: "1",
          name: `Café ${Math.floor(location.lat * 100) % 10}`,
          type: "Coffee Shop",
          distance: "0.2 miles",
          address: `${Math.floor(Math.abs(location.lng * 10) % 100)} Main St`,
          icon: Coffee,
        },
        {
          id: "2",
          name: `Market ${Math.floor(location.lng * 100) % 10}`,
          type: "Grocery Store",
          distance: "0.5 miles",
          address: `${Math.floor(Math.abs(location.lat * 20) % 100)} Market Ave`,
          icon: ShoppingCart,
        },
        {
          id: "3",
          name: `Restaurant ${String.fromCharCode(65 + Math.floor(Math.abs(location.lat * 10) % 26))}`,
          type: "Restaurant",
          distance: "0.7 miles",
          address: `${Math.floor(Math.abs(location.lng * 30) % 100)} Food Blvd`,
          icon: Utensils,
        },
        {
          id: "4",
          name: `Shop ${String.fromCharCode(65 + Math.floor(Math.abs(location.lng * 10) % 26))}`,
          type: "Retail Store",
          distance: "1.0 miles",
          address: `${Math.floor(Math.abs(location.lat * 40) % 100)} Shopping Center`,
          icon: Store,
        },
      ];
      
      setPlaces(mockPlaces);
      setLoading(false);
    };

    if (location) {
      fetchNearbyPlaces();
    }
  }, [location]);

  if (loading) {
    return (
      <div className="px-6 py-8 text-center">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-3 text-neutral-medium">Finding shops near you...</p>
      </div>
    );
  }

  return (
    <div className="px-6 py-4">
      <h3 className="font-bold mb-3 text-lg flex items-center">
        <MapPin className="mr-2 text-primary" size={18} />
        Nearby Shops
      </h3>
      
      <div className="space-y-3 mb-4">
        {places.map((place, index) => (
          <motion.div
            key={place.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.3 }}
          >
            <Card className="overflow-hidden border-none shadow-soft">
              <CardContent className="p-0">
                <div className="flex items-center p-4">
                  <div className="bg-blue-50 p-3 rounded-full mr-4">
                    <place.icon size={20} className="text-primary" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{place.name}</h4>
                    <p className="text-sm text-neutral-medium">{place.type} • {place.distance}</p>
                    <p className="text-xs text-neutral-medium mt-1">{place.address}</p>
                  </div>
                  <div className="text-xs bg-primary/10 text-primary font-semibold rounded-full px-3 py-1">
                    4.5% Back
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
      
      <p className="text-center text-xs text-neutral-medium italic">
        Information based on your current location
      </p>
    </div>
  );
};

export default NearbyShops;
