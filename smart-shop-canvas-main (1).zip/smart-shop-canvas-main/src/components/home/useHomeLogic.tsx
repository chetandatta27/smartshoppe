import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { Notification } from "../notifications/NotificationTypes";
import { Language } from "../language/LanguageTypes";

const useHomeLogic = () => {
  const [showPersonalized, setShowPersonalized] = useState<boolean>(true);
  const [showNearbyShops, setShowNearbyShops] = useState<boolean>(false);
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [showComparisonTool, setShowComparisonTool] = useState<boolean>(false);
  const [showNotifications, setShowNotifications] = useState<boolean>(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [showLanguageSelector, setShowLanguageSelector] = useState<boolean>(false);
  const [currentLanguage, setCurrentLanguage] = useState<Language>({
    code: "en",
    name: "English",
    nativeName: "English"
  });
  const [savedShops, setSavedShops] = useState<string[]>([]);
  const [showNearbyDealsMap, setShowNearbyDealsMap] = useState<boolean>(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  // On mount, simulate getting user location
  useEffect(() => {
    const mockLocation = { lat: 51.507359, lng: -0.136439 };
    
    // Generate mock notifications
    const mockNotifications: Notification[] = [
      {
        id: "n1",
        type: "deal",
        title: "New Deal at Starbucks",
        message: "Get 15% off your next coffee purchase with HDFC cards.",
        timestamp: new Date(),
        read: false,
        time: "2 min ago"
      },
      {
        id: "n2",
        type: "card",
        title: "Card Offer Expiring Soon",
        message: "Your ICICI card offer at Flipkart expires in 24 hours.",
        timestamp: new Date(Date.now() - 3600000),
        read: false,
        time: "1 hour ago"
      },
      {
        id: "n3",
        type: "location",
        title: "New Shops Nearby",
        message: "We found 3 shops with offers near you.",
        timestamp: new Date(Date.now() - 86400000),
        read: true,
        time: "1 day ago"
      },
    ];
    
    setNotifications(mockNotifications);
    setUnreadCount(mockNotifications.filter(n => !n.read).length);
    setSavedShops(["s1", "s4"]);
    
    const timer = setTimeout(() => {
      setLocation(mockLocation);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  // Function to handle search input
  const handleSearch = (query: string) => {
    if (query) {
      toast({
        title: "Searching",
        description: `Looking for "${query}"`,
      });
    }
  };

  // Function to handle location search
  const handleLocationSearch = () => {
    setShowNearbyShops(true);
    toast({
      title: "Finding nearby offers",
      description: "Searching for offers near you",
    });
  };

  // Function to handle shop selection
  const handleShopSelect = (shopId: string) => {
    navigate(`/shop/${shopId}`);
  };

  // Function to view preferences
  const handleViewPreferences = () => {
    setShowComparisonTool(true);
  };

  // Function to show map
  const handleShowMap = () => {
    if (location) {
      setShowNearbyDealsMap(true);
    } else {
      toast({
        title: "Location not available",
        description: "Please enable location access",
        variant: "destructive",
      });
    }
  };

  // Function to toggle notifications
  const handleToggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };

  // Function to toggle saving a shop
  const handleToggleSaveShop = (shopId: string) => {
    setSavedShops(prev => {
      if (prev.includes(shopId)) {
        return prev.filter(id => id !== shopId);
      } else {
        toast({
          title: "Shop saved",
          description: "Added to your saved shops",
        });
        return [...prev, shopId];
      }
    });
  };

  // Function to mark notification as read
  const handleMarkNotificationRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true } 
          : notification
      )
    );
    
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  // Function to clear all notifications
  const handleClearAllNotifications = () => {
    setNotifications([]);
    setUnreadCount(0);
    toast({
      title: "Notifications cleared",
      description: "All notifications have been removed",
    });
  };

  // Function to handle language change
  const handleLanguageChange = (language: Language) => {
    setCurrentLanguage(language);
    setShowLanguageSelector(false);
    toast({
      title: "Language changed",
      description: `Language set to ${language.name}`,
    });
  };

  // Navigate to rewards
  const navigateToRewards = () => {
    navigate('/rewards');
  };

  // Navigate to saved shops
  const navigateToSavedShops = () => {
    navigate('/saved-shops');
  };

  return {
    showPersonalized,
    setShowPersonalized,
    showNearbyShops,
    location,
    showComparisonTool,
    setShowComparisonTool,
    showNotifications,
    setShowNotifications,
    notifications,
    unreadCount,
    showLanguageSelector,
    setShowLanguageSelector,
    currentLanguage,
    savedShops,
    showNearbyDealsMap,
    setShowNearbyDealsMap,
    handleSearch,
    handleLocationSearch,
    handleShopSelect,
    handleViewPreferences,
    handleShowMap,
    handleToggleNotifications,
    handleToggleSaveShop,
    handleMarkNotificationRead,
    handleClearAllNotifications,
    handleLanguageChange,
    navigateToRewards,
    navigateToSavedShops
  };
};

export default useHomeLogic;
