
import React from "react";
import { motion } from "framer-motion";
import BottomNavigation from "../layout/BottomNavigation";
import NearbyShops from "./NearbyShops";
import CardComparisonTool from "../comparison/CardComparisonTool";
import NotificationCenter from "../notifications/NotificationCenter";
import LanguageSelector from "../language/LanguageSelector";
import RealtimeShopMap from "../maps/RealtimeShopMap";
import { MOCK_SHOPS, MOCK_CARDS, MY_CARDS, LANGUAGES } from "./MockData";
import HomeHeader from "./HomeHeader";
import ShopsSection from "./ShopsSection";
import CardsSection from "./CardsSection";
import HomeActions from "./HomeActions";
import useHomeLogic from "./useHomeLogic";

const HomeScreen: React.FC = () => {
  const {
    showPersonalized,
    setShowPersonalized,
    showNearbyShops,
    location,
    showComparisonTool,
    setShowComparisonTool,
    showNotifications,
    setShowNotifications,
    notifications,
    unreadCount,
    showLanguageSelector,
    setShowLanguageSelector,
    currentLanguage,
    savedShops,
    showNearbyDealsMap,
    setShowNearbyDealsMap,
    handleSearch,
    handleLocationSearch,
    handleShopSelect,
    handleViewPreferences,
    handleShowMap,
    handleToggleNotifications,
    handleToggleSaveShop,
    handleMarkNotificationRead,
    handleClearAllNotifications,
    handleLanguageChange,
    navigateToRewards,
    navigateToSavedShops
  } = useHomeLogic();

  return (
    <div className="min-h-screen bg-neutral-white pb-20">
      {/* Header with search */}
      <HomeHeader 
        unreadCount={unreadCount}
        handleToggleNotifications={handleToggleNotifications}
        handleSearch={handleSearch}
        handleLocationSearch={handleLocationSearch}
      />

      {/* Nearby Shops */}
      {showNearbyShops && location && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className="overflow-hidden"
        >
          <NearbyShops location={location} />
        </motion.div>
      )}

      {/* Shop Carousel */}
      <ShopsSection 
        shops={MOCK_SHOPS}
        onShopSelect={handleShopSelect}
        savedShops={savedShops}
        onToggleSaveShop={handleToggleSaveShop}
      />

      {/* Card Carousel */}
      <CardsSection 
        showPersonalized={showPersonalized}
        personalizedCards={MY_CARDS}
        recommendedCards={MOCK_CARDS}
        onTogglePersonalized={setShowPersonalized}
      />

      {/* Action Buttons */}
      <HomeActions 
        handleViewPreferences={handleViewPreferences}
        handleShowMap={handleShowMap}
        navigateToRewards={navigateToRewards}
        navigateToSavedShops={navigateToSavedShops}
      />

      {/* Modals and Overlays */}
      {showComparisonTool && (
        <CardComparisonTool 
          cards={showPersonalized ? MY_CARDS : MOCK_CARDS} 
          onClose={() => setShowComparisonTool(false)} 
        />
      )}
      
      {showNotifications && (
        <NotificationCenter 
          notifications={notifications}
          onClose={() => setShowNotifications(false)}
          onMarkRead={handleMarkNotificationRead}
          onClearAll={handleClearAllNotifications}
        />
      )}
      
      {showLanguageSelector && (
        <LanguageSelector
          currentLanguage={currentLanguage}
          languages={LANGUAGES}
          onSelectLanguage={handleLanguageChange}
          onClose={() => setShowLanguageSelector(false)}
        />
      )}
      
      {showNearbyDealsMap && location && (
        <RealtimeShopMap
          location={location}
          shops={MOCK_SHOPS}
          onClose={() => setShowNearbyDealsMap(false)}
          onSelectShop={handleShopSelect}
        />
      )}

      <BottomNavigation />
    </div>
  );
};

export default HomeScreen;
