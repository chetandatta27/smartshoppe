import { Shop } from "../shops/ShopTypes";
import { CardOffer } from "../shops/ShopTypes";
import { Notification } from "../notifications/NotificationTypes";
import { Language } from "../language/LanguageTypes";

// Sample shops with location information
export const MOCK_SHOPS: Shop[] = [
  {
    id: "1",
    name: "Starbucks",
    logo: "https://logo.clearbit.com/starbucks.com",
    isPartner: true,
    distance: "0.3 miles",
    savingsAmount: "₹75",
    cardTypes: ["Visa", "Mastercard"],
    offerExpiry: "3 days",
    location: { lat: 37.7815, lng: -122.4200 }
  },
  {
    id: "2",
    name: "McDonald's",
    logo: "https://logo.clearbit.com/mcdonalds.com",
    isPartner: true,
    distance: "0.5 miles",
    savingsAmount: "₹100",
    cardTypes: ["Visa", "Amex"],
    offerExpiry: "5 days",
    location: { lat: 37.7835, lng: -122.4170 }
  },
  {
    id: "3",
    name: "Nike",
    logo: "https://logo.clearbit.com/nike.com",
    isPartner: false,
    distance: "0.8 miles",
    savingsAmount: "₹250",
    cardTypes: ["Mastercard"],
    offerExpiry: "2 days",
    location: { lat: 37.7870, lng: -122.4230 }
  },
  {
    id: "4",
    name: "Apple Store",
    logo: "https://logo.clearbit.com/apple.com",
    isPartner: true,
    distance: "1.2 miles",
    savingsAmount: "₹500",
    cardTypes: ["Amex", "Visa"],
    offerExpiry: "7 days",
    location: { lat: 37.7890, lng: -122.4120 }
  },
  {
    id: "5",
    name: "Zara",
    logo: "https://logo.clearbit.com/zara.com",
    isPartner: false,
    distance: "1.5 miles",
    savingsAmount: "₹150",
    cardTypes: ["Visa", "Mastercard"],
    offerExpiry: "4 days",
    location: { lat: 37.7840, lng: -122.4090 }
  }
];

// Sample cards
export const MOCK_CARDS: CardOffer[] = [
  {
    id: "mc1",
    bank: "HDFC",
    network: "Mastercard",
    cashback: "5%",
    color: "#FF5733",
    badge: "Best Seller",
    offerDetails: "Get 5% cashback on all purchases",
    minSpend: "₹500",
    cashbackCap: "₹5000",
    processingTime: "2 days",
  },
  {
    id: "vi1",
    bank: "SBI",
    network: "Visa",
    cashback: "3%",
    color: "#3498DB",
    offerDetails: "Enjoy 3% cashback on online transactions",
    minSpend: "₹1000",
    cashbackCap: "₹3000",
    processingTime: "3 days",
  },
  {
    id: "ax1",
    bank: "Axis",
    network: "Amex",
    cashback: "7%",
    color: "#2ECC71",
    offerDetails: "Earn 7% cashback on dining and travel",
    minSpend: "₹2000",
    cashbackCap: "₹7000",
    processingTime: "1 day",
  },
  {
    id: "rc1",
    bank: "ICICI",
    network: "RuPay",
    cashback: "4%",
    color: "#9B59B6",
    offerDetails: "Get 4% cashback on utility bill payments",
    minSpend: "₹800",
    cashbackCap: "₹4000",
    processingTime: "4 days",
  },
  {
    id: "dc1",
    bank: "Kotak",
    network: "Diners Club",
    cashback: "6%",
    color: "#F39C12",
    offerDetails: "Receive 6% cashback on international spends",
    minSpend: "₹3000",
    cashbackCap: "₹6000",
    processingTime: "2 days",
  },
];

export const MY_CARDS: CardOffer[] = [
  {
    id: "mc2",
    bank: "HDFC",
    network: "Mastercard",
    cashback: "10%",
    color: "#E74C3C",
    badge: "Exclusive",
    offerDetails: "Get 10% cashback on all purchases",
    minSpend: "₹1000",
    cashbackCap: "₹10000",
    processingTime: "1 day",
    isUserCard: true,
  },
  {
    id: "vi2",
    bank: "SBI",
    network: "Visa",
    cashback: "8%",
    color: "#8E44AD",
    offerDetails: "Enjoy 8% cashback on online transactions",
    minSpend: "₹1500",
    cashbackCap: "₹8000",
    processingTime: "2 days",
    isUserCard: true,
  },
];

export const MOCK_NOTIFICATIONS: Notification[] = [
  {
    id: "n1",
    type: "offer",
    title: "New Offer Available",
    message: "Get 10% cashback on your next purchase at Starbucks with HDFC Mastercard.",
    timestamp: new Date(),
    read: false,
  },
  {
    id: "n2",
    type: "reminder",
    title: "Card Payment Due",
    message: "Your SBI Visa card payment of ₹5,000 is due on 25th July.",
    timestamp: new Date(Date.now() - 86400000), // 1 day ago
    read: false,
  },
  {
    id: "n3",
    type: "update",
    title: "App Update Available",
    message: "A new version of the app is available with exciting features and improvements.",
    timestamp: new Date(Date.now() - 172800000), // 2 days ago
    read: true,
  },
];

export const LANGUAGES: Language[] = [
  { code: "en", name: "English", nativeName: "English" },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी" },
  { code: "es", name: "Spanish", nativeName: "Español" },
  { code: "fr", name: "French", nativeName: "Français" },
  { code: "zh", name: "Chinese", nativeName: "中文" },
  { code: "ar", name: "Arabic", nativeName: "العربية" },
  { code: "ru", name: "Russian", nativeName: "Русский" },
  { code: "pt", name: "Portuguese", nativeName: "Português" },
  { code: "de", name: "German", nativeName: "Deutsch" },
  { code: "ja", name: "Japanese", nativeName: "日本語" }
];
