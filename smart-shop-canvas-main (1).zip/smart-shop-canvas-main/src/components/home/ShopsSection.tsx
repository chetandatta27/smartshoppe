
import React from "react";
import { motion } from "framer-motion";
import ShopCarousel from "../shops/ShopCarousel";
import { Shop } from "../shops/ShopCarousel";

interface ShopsSectionProps {
  shops: Shop[];
  onShopSelect: (shopId: string) => void;
  savedShops: string[];
  onToggleSaveShop: (shopId: string) => void;
}

const ShopsSection: React.FC<ShopsSectionProps> = ({
  shops,
  onShopSelect,
  savedShops,
  onToggleSaveShop,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: 0.2, duration: 0.3 }}
      className="mt-6 mb-6 px-4"
    >
      <ShopCarousel 
        shops={shops} 
        title="Popular Nearby Shops" 
        onShopSelect={onShopSelect}
        showFilters={true}
        savedShops={savedShops}
        onToggleSaveShop={onToggleSaveShop}
      />
    </motion.div>
  );
};

export default ShopsSection;
