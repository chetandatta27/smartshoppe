
export interface Notification {
  id: string;
  type: "location" | "card" | "info" | "deal" | "offer" | "reminder" | "update";
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  time?: string;
}
