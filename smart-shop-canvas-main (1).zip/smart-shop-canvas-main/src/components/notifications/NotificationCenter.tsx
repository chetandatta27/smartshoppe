
import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bell, X, MapPin, CreditCard, Info, ShoppingCart, Tag, Bell as Reminder, RefreshCcw } from "lucide-react";
import { Notification } from "./NotificationTypes";

interface NotificationCenterProps {
  notifications: Notification[];
  onClose: () => void;
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
}

const NotificationCenter: React.FC<NotificationCenterProps> = ({
  notifications,
  onClose,
  onMarkRead,
  onClearAll
}) => {
  const getIcon = (type: Notification["type"]) => {
    switch (type) {
      case "location":
        return <MapPin size={18} />;
      case "card":
        return <CreditCard size={18} />;
      case "deal":
        return <ShoppingCart size={18} />;
      case "offer":
        return <Tag size={18} />;
      case "reminder":
        return <Reminder size={18} />;
      case "update":
        return <RefreshCcw size={18} />;
      default:
        return <Info size={18} />;
    }
  };
  
  const getIconBackground = (type: Notification["type"]) => {
    switch (type) {
      case "location":
        return "bg-green-100 text-green-600";
      case "card":
        return "bg-blue-100 text-blue-600";
      case "deal":
        return "bg-orange-100 text-orange-600";
      case "offer":
        return "bg-purple-100 text-purple-600";
      case "reminder":
        return "bg-yellow-100 text-yellow-600";
      case "update":
        return "bg-teal-100 text-teal-600";
      default:
        return "bg-neutral-light/30 text-neutral-medium";
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/50 flex flex-col"
    >
      <div className="bg-white w-full flex-1 rounded-t-3xl mt-16 overflow-hidden flex flex-col">
        <div className="flex justify-between items-center p-4 border-b">
          <div className="flex items-center">
            <Bell size={20} className="text-primary mr-2" />
            <h2 className="text-lg font-bold">Notifications</h2>
            {notifications.some(n => !n.read) && (
              <Badge className="ml-2 bg-primary">{notifications.filter(n => !n.read).length}</Badge>
            )}
          </div>
          <div className="flex items-center gap-4">
            <button 
              className="text-sm text-neutral-medium"
              onClick={onClearAll}
            >
              Clear all
            </button>
            <button onClick={onClose}>
              <X size={20} />
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          <AnimatePresence>
            {notifications.length > 0 ? (
              notifications.map((notification) => (
                <motion.div
                  key={notification.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  onClick={() => onMarkRead(notification.id)}
                >
                  <Card className={notification.read ? "opacity-75" : ""}>
                    <CardContent className="p-3 flex">
                      <div className={`p-2 rounded-full mr-3 ${getIconBackground(notification.type)}`}>
                        {getIcon(notification.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <h3 className="font-medium text-sm">{notification.title}</h3>
                          <span className="text-xs text-neutral-medium">{notification.time}</span>
                        </div>
                        <p className="text-sm text-neutral-medium mt-1">{notification.message}</p>
                        {notification.action && (
                          <button
                            className="text-sm text-primary font-medium mt-2"
                            onClick={(e) => {
                              e.stopPropagation();
                              // Only access action.onClick if action exists
                              if (notification.action) {
                                notification.action.onClick();
                              }
                            }}
                          >
                            {notification.action.label}
                          </button>
                        )}
                      </div>
                      {!notification.read && (
                        <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1" />
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-neutral-medium py-10">
                <Bell size={30} className="mb-3 text-neutral-light" />
                <p>No notifications</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
};

export default NotificationCenter;
