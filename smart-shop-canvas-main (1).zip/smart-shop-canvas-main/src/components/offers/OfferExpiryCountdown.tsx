
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Clock } from "lucide-react";

interface OfferExpiryCountdownProps {
  expiryDate: Date;
  className?: string;
}

const OfferExpiryCountdown: React.FC<OfferExpiryCountdownProps> = ({
  expiryDate,
  className
}) => {
  const [timeLeft, setTimeLeft] = useState<{
    days: number;
    hours: number;
    minutes: number;
    seconds: number;
  }>({ days: 0, hours: 0, minutes: 0, seconds: 0 });
  
  const [isExpiring, setIsExpiring] = useState(false);

  useEffect(() => {
    const calculateTimeLeft = () => {
      const difference = expiryDate.getTime() - new Date().getTime();
      
      if (difference <= 0) {
        return { days: 0, hours: 0, minutes: 0, seconds: 0 };
      }
      
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);
      
      if (days === 0 && hours < 12) {
        setIsExpiring(true);
      }
      
      return { days, hours, minutes, seconds };
    };
    
    setTimeLeft(calculateTimeLeft());
    
    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    
    return () => clearInterval(timer);
  }, [expiryDate]);
  
  const formatNumber = (num: number) => {
    return num < 10 ? `0${num}` : num;
  };
  
  if (timeLeft.days === 0 && timeLeft.hours === 0 && timeLeft.minutes === 0 && timeLeft.seconds === 0) {
    return (
      <div className={`text-red-500 text-xs font-medium flex items-center ${className}`}>
        <Clock size={12} className="mr-1" />
        Expired
      </div>
    );
  }
  
  // Simplified display based on time left
  if (timeLeft.days > 0) {
    return (
      <div className={`text-xs flex items-center ${isExpiring ? "text-orange-500" : "text-neutral-medium"} ${className}`}>
        <Clock size={12} className="mr-1" />
        {timeLeft.days} {timeLeft.days === 1 ? "day" : "days"} left
      </div>
    );
  }
  
  if (timeLeft.hours > 0) {
    return (
      <div className={`text-xs flex items-center ${isExpiring ? "text-orange-500" : "text-neutral-medium"} ${className}`}>
        <Clock size={12} className="mr-1" />
        {timeLeft.hours} {timeLeft.hours === 1 ? "hr" : "hrs"} left
      </div>
    );
  }
  
  return (
    <motion.div 
      animate={{ scale: [1, 1.05, 1] }}
      transition={{ repeat: Infinity, duration: 1.5 }}
      className={`text-xs flex items-center text-red-500 font-medium ${className}`}
    >
      <Clock size={12} className="mr-1" />
      {formatNumber(timeLeft.minutes)}:{formatNumber(timeLeft.seconds)} left
    </motion.div>
  );
};

export default OfferExpiryCountdown;
