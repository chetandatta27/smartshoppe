
import React from "react";
import { MapPin, X } from "lucide-react";

interface MapHeaderProps {
  onClose: () => void;
  shopsCount: number;
  lastUpdateTime: Date;
}

const MapHeader: React.FC<MapHeaderProps> = ({ onClose, shopsCount, lastUpdateTime }) => {
  const formattedTime = lastUpdateTime.toLocaleTimeString([], { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  return (
    <div className="absolute top-0 left-0 right-0 z-10 p-4 bg-white shadow-lg">
      <div className="flex justify-between items-center">
        <div className="flex items-center">
          <MapPin className="text-primary mr-2" size={24} />
          <h2 className="text-xl font-bold">Nearby Offers</h2>
        </div>
        <button 
          onClick={onClose}
          className="w-10 h-10 flex items-center justify-center rounded-full hover:bg-gray-100"
          aria-label="Close map"
        >
          <X size={24} />
        </button>
      </div>
      
      <div className="mt-2">
        <p className="text-sm text-gray-600 font-medium">
          <span className="font-bold text-primary">{shopsCount} shops</span> nearby • 
          <span className="ml-1">Last updated: {formattedTime}</span>
        </p>
      </div>
    </div>
  );
};

export default MapHeader;
