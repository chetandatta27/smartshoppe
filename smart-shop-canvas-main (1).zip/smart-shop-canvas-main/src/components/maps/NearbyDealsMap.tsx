
import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { MapPin, X, Filter, CreditCard, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shop } from "../shops/ShopTypes";
import mapboxgl from "mapbox-gl";
import "mapbox-gl/dist/mapbox-gl.css";
import { toast } from "@/components/ui/use-toast";

interface MapLocation {
  lat: number;
  lng: number;
}

interface NearbyDealsMapProps {
  location: MapLocation;
  shops: Shop[];
  onClose: () => void;
  onSelectShop: (shopId: string) => void;
}

// IMPORTANT: In a production app, this token should be stored in an environment variable
// For this demo, we're hardcoding a temporary public token
const MAPBOX_TOKEN = "pk.eyJ1IjoibG92YWJsZWRldiIsImEiOiJjbHpiam92djIwMzFjMmxwZnhjYTV4Y2tqIn0.QJ7XLHFbs-viJI2JP-xZBQ";

const NearbyDealsMap: React.FC<NearbyDealsMapProps> = ({
  location,
  shops,
  onClose,
  onSelectShop
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string | null>(null);
  const [selectedShop, setSelectedShop] = useState<Shop | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [userLocation, setUserLocation] = useState<MapLocation>(location);
  const [nearbyShops, setNearbyShops] = useState<Shop[]>(shops);
  const [lastUpdateTime, setLastUpdateTime] = useState<Date>(new Date());
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<mapboxgl.Marker[]>([]);
  const userMarker = useRef<mapboxgl.Marker | null>(null);
  
  const filters = [
    { id: "all", name: "All" },
    { id: "visa", name: "Visa" },
    { id: "mastercard", name: "Mastercard" },
    { id: "amex", name: "Amex" },
    { id: "highest", name: "Highest Savings" },
  ];

  // Initialize map when component mounts
  useEffect(() => {
    if (!mapContainer.current || map.current) return;
    
    setIsLoading(true);
    mapboxgl.accessToken = MAPBOX_TOKEN;
    
    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/light-v11', // Use a lighter map style
        center: [location.lng, location.lat],
        zoom: 14,
        attributionControl: false
      });
      
      // Add navigation control
      map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
      
      // Add geolocation control with real-time updates
      map.current.addControl(
        new mapboxgl.GeolocateControl({
          positionOptions: {
            enableHighAccuracy: true
          },
          trackUserLocation: true,
          showUserHeading: true
        }),
        'top-right'
      );

      // Set up real-time location tracking
      if (navigator.geolocation) {
        navigator.geolocation.watchPosition(
          (position) => {
            const newLocation = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };
            setUserLocation(newLocation);
            updateUserMarker(newLocation);
            setLastUpdateTime(new Date());
            
            // Simulate finding new shops based on location changes
            simulateNewShopsDiscovery(newLocation);
          },
          (error) => {
            console.error("Error tracking location:", error);
          },
          {
            enableHighAccuracy: true,
            maximumAge: 0,
            timeout: 5000
          }
        );
      }
      
      map.current.on('load', () => {
        // Add user location marker with pulsing effect
        addUserMarker(location);
        
        // Add shops to the map
        addShopsToMap();
        
        // Fit map to bounds to show all markers
        fitMapToBounds();
        
        setIsLoading(false);
      });
      
      // Clean up on unmount
      return () => {
        document.querySelectorAll('.mapboxgl-popup').forEach(el => el.remove());
        if (map.current) {
          map.current.remove();
          map.current = null;
        }
      };
    } catch (error) {
      console.error("Error initializing map:", error);
      toast({
        title: "Map Error",
        description: "Failed to load the map. Please try again later.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  }, [location]);
  
  // Update user marker when location changes
  const updateUserMarker = (newLocation: MapLocation) => {
    if (map.current && userMarker.current) {
      userMarker.current.setLngLat([newLocation.lng, newLocation.lat]);
      
      // Smooth animation to new location
      map.current.easeTo({
        center: [newLocation.lng, newLocation.lat],
        duration: 1000,
        easing: (n) => n,
      });
    }
  };
  
  // Add user marker to map
  const addUserMarker = (loc: MapLocation) => {
    if (!map.current) return;
    
    // Create user marker element with pulsing effect
    const userMarkerEl = document.createElement('div');
    userMarkerEl.className = 'user-marker';
    userMarkerEl.style.width = '22px';
    userMarkerEl.style.height = '22px';
    userMarkerEl.style.borderRadius = '50%';
    userMarkerEl.style.backgroundColor = '#4668E0';
    userMarkerEl.style.border = '3px solid rgba(255, 255, 255, 0.8)';
    userMarkerEl.style.boxShadow = '0 0 0 rgba(70, 104, 224, 0.4)';
    userMarkerEl.style.animation = 'pulse 2s infinite';
    
    // Add pulse animation to head
    const style = document.createElement('style');
    style.textContent = `
      @keyframes pulse {
        0% {
          box-shadow: 0 0 0 0 rgba(70, 104, 224, 0.4);
        }
        70% {
          box-shadow: 0 0 0 10px rgba(70, 104, 224, 0);
        }
        100% {
          box-shadow: 0 0 0 0 rgba(70, 104, 224, 0);
        }
      }
    `;
    document.head.appendChild(style);
    
    userMarker.current = new mapboxgl.Marker(userMarkerEl)
      .setLngLat([loc.lng, loc.lat])
      .addTo(map.current);
  };
  
  // Simulate discovering new shops based on location changes
  const simulateNewShopsDiscovery = (newLocation: MapLocation) => {
    // Only update occasionally to avoid too many updates
    if (Math.random() > 0.3) return;
    
    // Generate a new shop in the vicinity of the user
    const angle = Math.random() * Math.PI * 2;
    const distance = 0.001 + Math.random() * 0.003; // Random distance
    const shopLocation = {
      lat: newLocation.lat + distance * Math.cos(angle),
      lng: newLocation.lng + distance * Math.sin(angle)
    };
    
    const newShop: Shop = {
      id: `dynamic-${Date.now()}`,
      name: `Shop ${Math.floor(Math.random() * 100)}`,
      logo: `https://ui-avatars.com/api/?name=S${Math.floor(Math.random() * 100)}&background=4A66E4&color=fff`,
      isPartner: Math.random() > 0.5,
      distance: `${(distance * 100).toFixed(1)} km`,
      savingsAmount: `₹${Math.floor(Math.random() * 500)}`,
      cardTypes: ["Visa", "Mastercard"].filter(() => Math.random() > 0.5),
      offerExpiry: `${Math.floor(Math.random() * 5) + 1} days`,
      location: shopLocation
    };
    
    // Add new shop to the list
    setNearbyShops(prev => {
      const updated = [...prev, newShop];
      
      // Add marker for the new shop
      if (map.current) {
        addShopMarker(newShop);
      }
      
      toast({
        title: "New shop discovered!",
        description: `${newShop.name} is ${newShop.distance} away with savings of ${newShop.savingsAmount}`,
      });
      
      return updated;
    });
  };
  
  // Add a single shop marker
  const addShopMarker = (shop: Shop) => {
    if (!map.current || !shop.location) return;
    
    const el = document.createElement('div');
    el.className = 'shop-marker';
    el.style.width = shop.isPartner ? '38px' : '32px';
    el.style.height = shop.isPartner ? '38px' : '32px';
    el.style.borderRadius = '50%';
    el.style.backgroundColor = shop.isPartner ? '#4668E0' : 'white';
    el.style.border = '2px solid white';
    el.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
    el.style.display = 'flex';
    el.style.alignItems = 'center';
    el.style.justifyContent = 'center';
    el.style.transition = 'all 0.3s ease';
    el.style.cursor = 'pointer';
    
    // Add hover effect
    el.onmouseover = () => {
      el.style.transform = 'scale(1.1)';
      el.style.boxShadow = '0 4px 10px rgba(0,0,0,0.4)';
    };
    
    el.onmouseout = () => {
      el.style.transform = 'scale(1)';
      el.style.boxShadow = '0 2px 6px rgba(0,0,0,0.3)';
    };
    
    // Create logo element
    const logo = document.createElement('img');
    logo.src = shop.logo;
    logo.style.width = shop.isPartner ? '24px' : '18px';
    logo.style.height = shop.isPartner ? '24px' : '18px';
    logo.style.objectFit = 'contain';
    logo.onerror = () => {
      logo.src = `https://ui-avatars.com/api/?name=${shop.name}&background=4A66E4&color=fff`;
    };
    
    el.appendChild(logo);
    
    // Create a marker
    const marker = new mapboxgl.Marker(el)
      .setLngLat([shop.location.lng, shop.location.lat])
      .addTo(map.current);
    
    // Add popup with shop info
    const popup = new mapboxgl.Popup({
      closeButton: false,
      closeOnClick: false,
      offset: 25,
      className: 'shop-popup'
    }).setHTML(`
      <div class="p-2">
        <div class="font-bold text-sm">${shop.name}</div>
        <div class="text-xs text-neutral-medium">${shop.distance || '0.5 miles'} away</div>
        ${shop.savingsAmount ? `<div class="text-xs mt-1">Save up to <span class="font-bold text-primary">${shop.savingsAmount}</span></div>` : ''}
      </div>
    `);
    
    // Show popup on hover
    el.addEventListener('mouseenter', () => {
      marker.setPopup(popup);
      popup.addTo(map.current!);
    });
    
    el.addEventListener('mouseleave', () => {
      popup.remove();
    });
    
    // Add click event
    el.addEventListener('click', () => {
      handleSelectShop(shop);
    });
    
    // Store marker reference for cleanup
    markers.current.push(marker);
    
    // Add entrance animation
    el.animate([
      { opacity: 0, transform: 'scale(0)' },
      { opacity: 1, transform: 'scale(1)' }
    ], {
      duration: 300,
      easing: 'ease-out'
    });
    
    return marker;
  };
  
  // Filter shops based on selected filter
  const filteredShops = selectedFilter
    ? nearbyShops.filter(shop => {
        if (selectedFilter === 'highest') {
          return shop.savingsAmount && parseFloat(shop.savingsAmount.replace('₹', '')) > 100;
        }
        return shop.cardTypes?.some(type => 
          type.toLowerCase().includes(selectedFilter.toLowerCase())
        );
      })
    : nearbyShops;
  
  // Add shops to map
  const addShopsToMap = () => {
    if (!map.current) return;
    
    // Clear existing markers
    markers.current.forEach(marker => marker.remove());
    markers.current = [];
    
    // Add shop markers
    filteredShops.forEach((shop) => {
      if (!shop.location) return;
      addShopMarker(shop);
    });
  };
  
  // Update markers when filters change
  useEffect(() => {
    addShopsToMap();
    fitMapToBounds();
  }, [selectedFilter, nearbyShops]);
  
  // Fit map to bounds
  const fitMapToBounds = () => {
    if (!map.current || markers.current.length === 0) return;
    
    const bounds = new mapboxgl.LngLatBounds();
    
    // Add user location to bounds
    bounds.extend([userLocation.lng, userLocation.lat]);
    
    // Add all shop markers to bounds
    markers.current.forEach(marker => {
      bounds.extend(marker.getLngLat());
    });
    
    // Fit map to bounds with padding
    map.current.fitBounds(bounds, {
      padding: { top: 100, bottom: 200, left: 50, right: 50 },
      maxZoom: 15
    });
  };
  
  const handleSelectShop = (shop: Shop) => {
    setSelectedShop(shop);
  };
  
  const handleFilterShops = (filterId: string) => {
    setSelectedFilter(selectedFilter === filterId ? null : filterId);
  };
  
  const handleViewOffer = () => {
    if (selectedShop) {
      onSelectShop(selectedShop.id);
      onClose();
    }
  };
  
  const handleGetDirections = () => {
    if (selectedShop?.location) {
      // Open Google Maps with directions
      const url = `https://www.google.com/maps/dir/?api=1&destination=${selectedShop.location.lat},${selectedShop.location.lng}&travelmode=driving`;
      window.open(url, '_blank');
      
      toast({
        title: "Opening directions",
        description: "Directions to " + selectedShop.name + " in Google Maps",
      });
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-white flex flex-col"
    >
      <div className="absolute top-0 left-0 right-0 z-10 p-4 bg-white/95 backdrop-blur-md shadow-md">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-bold flex items-center">
            <MapPin className="mr-2 text-primary" size={20} />
            Nearby Offers
          </h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X size={22} />
          </Button>
        </div>
        
        <div className="mt-3 mb-1">
          <p className="text-xs text-gray-500">
            Last updated: {lastUpdateTime.toLocaleTimeString()} • 
            {filteredShops.length} shops nearby
          </p>
        </div>
        
        <div className="mb-3 overflow-x-auto flex gap-2 pb-2">
          {filters.map((filter) => (
            <Badge
              key={filter.id}
              variant={selectedFilter === filter.id ? "default" : "outline"}
              className="cursor-pointer whitespace-nowrap"
              onClick={() => handleFilterShops(filter.id)}
            >
              {filter.id === "all" && selectedFilter === null && (
                <Filter size={12} className="mr-1" />
              )}
              {filter.name}
            </Badge>
          ))}
        </div>
      </div>
      
      <div className="flex-1 mt-28 relative">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/80 z-10">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        )}
        {/* Map container */}
        <div ref={mapContainer} className="w-full h-full" />
      </div>
      
      {selectedShop && (
        <motion.div
          initial={{ y: 100 }}
          animate={{ y: 0 }}
          className="bg-white rounded-t-3xl p-4 shadow-lg"
        >
          <div className="flex items-center mb-3">
            <div className="bg-neutral-light/10 p-3 rounded-xl mr-3">
              <img 
                src={selectedShop.logo} 
                alt={selectedShop.name}
                className="w-12 h-12 object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = `https://ui-avatars.com/api/?name=${selectedShop.name}&background=4A66E4&color=fff`;
                }}
              />
            </div>
            <div className="flex-1">
              <div className="flex items-center">
                <h3 className="font-bold text-lg">{selectedShop.name}</h3>
                {selectedShop.isPartner && (
                  <Badge className="ml-2 bg-primary text-white text-xs">Partner</Badge>
                )}
              </div>
              <p className="text-sm text-neutral-medium">{selectedShop.distance || '0.5 miles'} away</p>
            </div>
          </div>
          
          <Card className="mb-4 border border-neutral-light/20">
            <CardContent className="p-3">
              <div className="flex items-center">
                <div className="bg-primary/10 p-2 rounded-full mr-3">
                  <CreditCard size={18} className="text-primary" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-sm">Best Card Offer</h4>
                  <p className="text-xs text-neutral-medium">
                    Use <span className="font-medium">HDFC Regalia</span> to get {selectedShop.savingsAmount || '₹150'} back
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline"
              className="flex items-center justify-center"
              onClick={handleGetDirections}
            >
              <Navigation size={18} className="mr-2" />
              Get Directions
            </Button>
            <Button 
              onClick={handleViewOffer}
            >
              View Offers
            </Button>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default NearbyDealsMap;
