
import React, { useEffect } from "react";
import mapboxgl from "mapbox-gl";
import { useMapContext } from "./MapContext";

interface MapLocation {
  lat: number;
  lng: number;
}

interface UserLocationMarkerProps {
  initialLocation: MapLocation;
}

const UserLocationMarker: React.FC<UserLocationMarkerProps> = ({ initialLocation }) => {
  const { map, userMarker, userLocation, setUserLocation } = useMapContext();

  // Initialize user marker and watch position
  useEffect(() => {
    if (!map.current) return;
    
    // Add user location marker with enhanced pulsing effect
    addUserMarker(initialLocation);
    
    // Set the user location but don't use real-time tracking
    setUserLocation(initialLocation);
    
    // Skip real-time geolocation tracking since we want static map
  }, [initialLocation, map.current]);

  // Add user marker to map with enhanced visibility
  const addUserMarker = (loc: MapLocation) => {
    if (!map.current) return;
    
    // Create user marker element with enhanced pulsing effect
    const userMarkerEl = document.createElement('div');
    userMarkerEl.className = 'user-marker';
    userMarkerEl.style.width = '30px';
    userMarkerEl.style.height = '30px';
    userMarkerEl.style.borderRadius = '50%';
    userMarkerEl.style.backgroundColor = '#4668E0';
    userMarkerEl.style.border = '5px solid rgba(255, 255, 255, 0.9)';
    userMarkerEl.style.boxShadow = '0 0 0 rgba(70, 104, 224, 0.6)';
    userMarkerEl.style.animation = 'pulse 2s infinite';
    userMarkerEl.style.zIndex = '50';
    
    // Add enhanced pulse animation to head
    const style = document.createElement('style');
    style.textContent = `
      @keyframes pulse {
        0% {
          box-shadow: 0 0 0 0 rgba(70, 104, 224, 0.7);
        }
        70% {
          box-shadow: 0 0 0 18px rgba(70, 104, 224, 0);
        }
        100% {
          box-shadow: 0 0 0 0 rgba(70, 104, 224, 0);
        }
      }
    `;
    document.head.appendChild(style);
    
    // Add more visible radius circle around user location
    map.current.on('load', () => {
      // Check if the source already exists
      if (!map.current?.getSource('user-radius')) {
        map.current?.addSource('user-radius', {
          type: 'geojson',
          data: {
            type: 'Feature',
            geometry: {
              type: 'Point',
              coordinates: [loc.lng, loc.lat]
            },
            properties: {}
          }
        });
        
        // Add a more visible circle around the user location
        map.current?.addLayer({
          id: 'user-radius-circle',
          type: 'circle',
          source: 'user-radius',
          paint: {
            'circle-radius': 140,
            'circle-color': 'rgba(70, 104, 224, 0.2)',
            'circle-stroke-width': 3,
            'circle-stroke-color': 'rgba(70, 104, 224, 0.5)'
          }
        });
      }
    });
    
    userMarker.current = new mapboxgl.Marker(userMarkerEl)
      .setLngLat([loc.lng, loc.lat])
      .addTo(map.current);
  };
  
  return null; // This component doesn't render anything
};

export default UserLocationMarker;
