
import React, { useEffect } from "react";
import mapboxgl from "mapbox-gl";
import { Shop } from "../shops/ShopTypes";
import { useMapContext } from "./MapContext";

interface ShopMarkersProps {
  shops: Shop[];
}

const ShopMarkers: React.FC<ShopMarkersProps> = ({ shops }) => {
  const { map, markers, userLocation, setSelectedShop } = useMapContext();
  
  // Add a single shop marker with enhanced visibility
  const addShopMarker = (shop: Shop) => {
    if (!map.current || !shop.location) return;
    
    const el = document.createElement('div');
    el.className = 'shop-marker';
    el.style.width = shop.isPartner ? '52px' : '46px';
    el.style.height = shop.isPartner ? '52px' : '46px';
    el.style.borderRadius = '50%';
    el.style.backgroundColor = shop.isPartner ? '#ea384c' : '#ff6b6b'; // Enhanced red colors for visibility
    el.style.border = '4px solid white';
    el.style.boxShadow = '0 4px 10px rgba(0,0,0,0.5)';
    el.style.display = 'flex';
    el.style.alignItems = 'center';
    el.style.justifyContent = 'center';
    el.style.transition = 'all 0.3s ease';
    el.style.cursor = 'pointer';
    el.style.zIndex = '10';
    
    // Add enhanced hover effect with animation
    el.onmouseover = () => {
      el.style.transform = 'scale(1.2)';
      el.style.boxShadow = '0 6px 14px rgba(0,0,0,0.6)';
    };
    
    el.onmouseout = () => {
      el.style.transform = 'scale(1)';
      el.style.boxShadow = '0 4px 10px rgba(0,0,0,0.5)';
    };
    
    // Create logo element with enhanced size
    const logo = document.createElement('img');
    logo.src = shop.logo;
    logo.style.width = shop.isPartner ? '32px' : '28px';
    logo.style.height = shop.isPartner ? '32px' : '28px';
    logo.style.objectFit = 'contain';
    logo.onerror = () => {
      logo.src = `https://ui-avatars.com/api/?name=${shop.name}&background=EA384C&color=fff`;
    };
    
    el.appendChild(logo);
    
    // Create a marker
    const marker = new mapboxgl.Marker(el)
      .setLngLat([shop.location.lng, shop.location.lat])
      .addTo(map.current);
    
    // Add click event with enhanced animation
    el.addEventListener('click', () => {
      // Highlight the selected marker
      markers.current.forEach((m) => {
        const markerElement = m.getElement();
        markerElement.style.zIndex = '10';
        markerElement.style.boxShadow = '0 4px 10px rgba(0,0,0,0.5)';
      });
      
      el.style.zIndex = '20';
      el.style.boxShadow = '0 8px 20px rgba(234, 56, 76, 0.7)';
      
      // Animate selection
      el.animate([
        { transform: 'scale(1)' },
        { transform: 'scale(1.3)' },
        { transform: 'scale(1.15)' }
      ], {
        duration: 500,
        easing: 'ease-out'
      });
      
      setSelectedShop(shop);
    });
    
    // Store marker reference for cleanup
    markers.current.push(marker);
    
    // Add entrance animation
    el.animate([
      { opacity: 0, transform: 'scale(0)' },
      { opacity: 1, transform: 'scale(1.2)' },
      { opacity: 1, transform: 'scale(1)' }
    ], {
      duration: 500,
      easing: 'ease-out'
    });
    
    return marker;
  };
  
  // Add shops to map
  const addShopsToMap = () => {
    if (!map.current) return;
    
    // Clear existing markers
    markers.current.forEach(marker => marker.remove());
    markers.current = [];
    
    // Add shop markers
    shops.forEach((shop) => {
      if (!shop.location) return;
      addShopMarker(shop);
    });
  };
  
  // Fit map to bounds
  const fitMapToBounds = () => {
    if (!map.current || markers.current.length === 0) return;
    
    const bounds = new mapboxgl.LngLatBounds();
    
    // Add user location to bounds
    bounds.extend([userLocation.lng, userLocation.lat]);
    
    // Add all shop markers to bounds
    markers.current.forEach(marker => {
      bounds.extend(marker.getLngLat());
    });
    
    // Fit map to bounds with improved padding for better visibility
    map.current.fitBounds(bounds, {
      padding: { top: 120, bottom: 220, left: 60, right: 60 },
      maxZoom: 15
    });
  };
  
  // Update markers when shops data changes - no real-time updates
  useEffect(() => {
    if (map.current) {
      addShopsToMap();
      fitMapToBounds();
    }
  }, [shops, map.current]);
  
  return null; // This component doesn't render anything
};

export default ShopMarkers;
