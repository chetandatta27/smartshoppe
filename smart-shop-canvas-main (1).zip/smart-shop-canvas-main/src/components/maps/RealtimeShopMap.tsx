
import React, { useState } from "react";
import { motion } from "framer-motion";
import { Shop } from "../shops/ShopTypes";
import { MapProvider } from "./MapContext";
import MapHeader from "./MapHeader";
import MapContainer from "./MapContainer";
import UserLocationMarker from "./UserLocationMarker";
import ShopMarkers from "./ShopMarkers";
import ShopDetailsPanel from "./ShopDetailsPanel";
import "mapbox-gl/dist/mapbox-gl.css";

interface MapLocation {
  lat: number;
  lng: number;
}

interface RealtimeShopMapProps {
  location: MapLocation;
  shops: Shop[];
  onClose: () => void;
  onSelectShop: (shopId: string) => void;
}

const RealtimeShopMap: React.FC<RealtimeShopMapProps> = ({
  location,
  shops,
  onClose,
  onSelectShop
}) => {
  // Use a fixed timestamp instead of real-time updates
  const [lastUpdateTime] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  
  // Filter shops with valid location
  const shopsWithLocation = shops.filter(shop => shop.location);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-white flex flex-col"
    >
      <MapProvider initialLocation={location}>
        <MapHeader 
          onClose={onClose} 
          shopsCount={shopsWithLocation.length}
          lastUpdateTime={lastUpdateTime} 
        />
        
        <div className="flex-1 relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/90 z-10">
              <div className="animate-spin rounded-full h-14 w-14 border-b-2 border-primary"></div>
            </div>
          )}
          
          <MapContainer initialLocation={location} />
          <UserLocationMarker initialLocation={location} />
          <ShopMarkers shops={shopsWithLocation} />
        </div>
        
        <ShopDetailsPanel onViewOffer={onSelectShop} />
      </MapProvider>
    </motion.div>
  );
};

export default RealtimeShopMap;
