
import React, { useRef, useEffect } from 'react';
import mapboxgl from 'mapbox-gl';
import { toast } from "@/components/ui/use-toast";
import { useMapContext } from './MapContext';

// IMPORTANT: In a production app, this token should be stored in an environment variable
const MAPBOX_TOKEN = "pk.eyJ1IjoibG92YWJsZWRldiIsImEiOiJjbHpiam92djIwMzFjMmxwZnhjYTV4Y2tqIn0.QJ7XLHFbs-viJI2JP-xZBQ";

interface MapContainerProps {
  initialLocation: { lat: number; lng: number };
}

const MapContainer: React.FC<MapContainerProps> = ({ initialLocation }) => {
  const { map, setIsLoading } = useMapContext();
  const mapContainer = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!mapContainer.current || map.current) return;
    
    setIsLoading(true);
    mapboxgl.accessToken = MAPBOX_TOKEN;
    
    try {
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/light-v11', // Light style for better visibility
        center: [initialLocation.lng, initialLocation.lat],
        zoom: 14,
        attributionControl: false,
        interactive: true, // Keep this true for basic interactions
        renderWorldCopies: false
      });
      
      // Add minimal UI with more visible controls
      map.current.addControl(new mapboxgl.NavigationControl({
        showCompass: true,
        visualizePitch: true
      }), 'top-right');
      
      map.current.on('load', () => {
        // Add improved visibility elements
        if (map.current) {
          // Add subtle grid lines for better spatial awareness
          map.current.addSource('grid', {
            'type': 'geojson',
            'data': {
              'type': 'Feature',
              'properties': {},
              'geometry': {
                'type': 'Polygon',
                'coordinates': [[]]
              }
            }
          });
          
          // Enhanced styling for better visibility
          map.current.addLayer({
            'id': 'land',
            'type': 'background',
            'paint': {
              'background-color': '#f8f9fa'
            }
          });
        }
        
        setIsLoading(false);
      });
      
      return () => {
        document.querySelectorAll('.mapboxgl-popup').forEach(el => el.remove());
        if (map.current) {
          map.current.remove();
          map.current = null;
        }
      };
    } catch (error) {
      console.error("Error initializing map:", error);
      toast({
        title: "Map Error",
        description: "Failed to load the map. Please try again later.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  }, [initialLocation]);
  
  return (
    <div ref={mapContainer} className="w-full h-full" />
  );
};

export default MapContainer;
