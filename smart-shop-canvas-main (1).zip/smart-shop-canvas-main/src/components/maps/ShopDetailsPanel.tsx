
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Navigation, CreditCard, Clock } from "lucide-react";
import { toast } from "@/components/ui/use-toast";
import { Shop } from "../shops/ShopTypes";
import { useMapContext } from "./MapContext";

interface ShopDetailsPanelProps {
  onViewOffer: (shopId: string) => void;
}

const ShopDetailsPanel: React.FC<ShopDetailsPanelProps> = ({ onViewOffer }) => {
  const { selectedShop } = useMapContext();
  
  if (!selectedShop) return null;
  
  const handleGetDirections = () => {
    if (selectedShop?.location) {
      // Show directions toast instead of opening actual maps
      toast({
        title: "Directions available",
        description: "Navigate to " + selectedShop.name + " (demo mode)",
      });
    }
  };
  
  const handleViewOffer = () => {
    onViewOffer(selectedShop.id);
  };
  
  return (
    <motion.div
      initial={{ y: 100 }}
      animate={{ y: 0 }}
      className="bg-white rounded-t-3xl p-5 shadow-xl absolute bottom-0 left-0 right-0 border-t border-neutral-100"
    >
      <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
      
      <div className="flex items-center mb-4">
        <div className="bg-white p-3 rounded-xl mr-3 shadow border border-neutral-100">
          <img 
            src={selectedShop.logo} 
            alt={selectedShop.name}
            className="w-16 h-16 object-contain"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = `https://ui-avatars.com/api/?name=${selectedShop.name}&background=4A66E4&color=fff&size=120`;
            }}
          />
        </div>
        <div className="flex-1">
          <div className="flex items-center">
            <h3 className="font-bold text-2xl">{selectedShop.name}</h3>
            {selectedShop.isPartner && (
              <Badge className="ml-2 bg-primary text-white px-2">Partner</Badge>
            )}
          </div>
          <p className="text-sm text-neutral-medium flex items-center mt-1">
            <span className="text-primary font-semibold">{selectedShop.distance || '0.5 miles'}</span> away
          </p>
        </div>
      </div>
      
      <Card className="mb-5 border-2 border-neutral-100 bg-neutral-50/50 shadow-sm">
        <CardContent className="p-4">
          <div className="flex items-center">
            <div className="bg-primary/15 p-3 rounded-full mr-3">
              <CreditCard size={24} className="text-primary" />
            </div>
            <div className="flex-1">
              <h4 className="font-semibold text-lg">Best Card Offer</h4>
              <p className="text-base text-neutral-medium">
                Use <span className="font-medium">HDFC Regalia</span> to get <span className="font-medium text-primary">{selectedShop.savingsAmount || '₹200'}</span> back
              </p>
            </div>
          </div>
          
          {selectedShop.offerExpiry && (
            <div className="flex items-center mt-3 pt-3 border-t border-neutral-100">
              <div className="text-amber-500 mr-2">
                <Clock size={18} />
              </div>
              <p className="text-sm font-medium text-neutral-dark">
                Offer expires in <span className="text-amber-600">{selectedShop.offerExpiry}</span>
              </p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="grid grid-cols-2 gap-4">
        <Button 
          variant="outline"
          className="flex items-center justify-center h-14 text-base font-medium"
          onClick={handleGetDirections}
        >
          <Navigation size={20} className="mr-2" />
          Get Directions
        </Button>
        <Button 
          onClick={handleViewOffer}
          className="h-14 bg-primary hover:bg-primary/90 text-base font-medium"
        >
          View Offers
        </Button>
      </div>
    </motion.div>
  );
};

export default ShopDetailsPanel;
