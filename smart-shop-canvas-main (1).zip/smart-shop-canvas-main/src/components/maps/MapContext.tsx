
import React, { createContext, useContext, useState, useRef } from "react";
import mapboxgl from "mapbox-gl";
import { Shop } from "../shops/ShopTypes";

interface MapLocation {
  lat: number;
  lng: number;
}

interface MapContextType {
  map: React.MutableRefObject<mapboxgl.Map | null>;
  userMarker: React.MutableRefObject<mapboxgl.Marker | null>;
  markers: React.MutableRefObject<mapboxgl.Marker[]>;
  isLoading: boolean;
  setIsLoading: (loading: boolean) => void;
  userLocation: MapLocation;
  setUserLocation: (location: MapLocation) => void;
  selectedShop: Shop | null;
  setSelectedShop: (shop: Shop | null) => void;
}

const MapContext = createContext<MapContextType | undefined>(undefined);

export const useMapContext = () => {
  const context = useContext(MapContext);
  if (!context) {
    throw new Error("useMapContext must be used within a MapProvider");
  }
  return context;
};

export const MapProvider: React.FC<{
  initialLocation: MapLocation;
  children: React.ReactNode;
}> = ({ initialLocation, children }) => {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [userLocation, setUserLocation] = useState<MapLocation>(initialLocation);
  const [selectedShop, setSelectedShop] = useState<Shop | null>(null);
  
  const map = useRef<mapboxgl.Map | null>(null);
  const userMarker = useRef<mapboxgl.Marker | null>(null);
  const markers = useRef<mapboxgl.Marker[]>([]);
  
  const value = {
    map,
    userMarker,
    markers,
    isLoading,
    setIsLoading,
    userLocation,
    setUserLocation,
    selectedShop,
    setSelectedShop
  };
  
  return (
    <MapContext.Provider value={value}>
      {children}
    </MapContext.Provider>
  );
};
