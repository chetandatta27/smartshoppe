
import React, { useState } from "react";
import { Input } from "@/components/ui/input";
import { Search, MapPin } from "lucide-react";

interface SearchBoxProps {
  onSearch: (query: string) => void;
  onLocationSearch: () => void;
  placeholder?: string;
}

const SearchBox: React.FC<SearchBoxProps> = ({ 
  onSearch, 
  onLocationSearch, 
  placeholder = "Search by shop name or address" 
}) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  return (
    <div className="relative w-full">
      <form onSubmit={handleSubmit} className="flex items-center w-full">
        <div className="relative w-full">
          <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-neutral-medium">
            <Search size={18} className={isFocused ? "text-primary" : ""} />
          </div>
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            placeholder={placeholder}
            className="pl-12 pr-12 py-6 bg-white border-none shadow-soft rounded-3xl focus:ring-primary/20 transition-all text-sm"
          />
        </div>
        <button
          type="button"
          onClick={onLocationSearch}
          className="absolute right-4 top-1/2 transform -translate-y-1/2 text-primary hover:text-primary/80 transition-colors"
          aria-label="Search by location"
        >
          <MapPin size={18} />
        </button>
      </form>
    </div>
  );
};

export default SearchBox;
