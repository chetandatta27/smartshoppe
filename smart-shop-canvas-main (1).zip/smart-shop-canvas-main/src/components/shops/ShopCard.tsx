
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Heart, Shield } from "lucide-react";
import { type Shop } from "./ShopCarousel";
import OfferExpiryCountdown from "../offers/OfferExpiryCountdown";

interface ShopCardProps {
  shop: Shop;
  isSaved?: boolean;
  onToggleSave?: (shopId: string) => void;
}

const ShopCard: React.FC<ShopCardProps> = ({ 
  shop, 
  isSaved = false,
  onToggleSave 
}) => {
  const handleToggleSave = () => {
    if (onToggleSave) {
      onToggleSave(shop.id);
    }
  };

  let expiryDate;
  if (shop.offerExpiry) {
    // For demo purposes, set expiry date based on the string
    const now = new Date();
    if (shop.offerExpiry.includes("hour")) {
      const hours = parseInt(shop.offerExpiry);
      expiryDate = new Date(now.getTime() + hours * 60 * 60 * 1000);
    } else if (shop.offerExpiry.includes("day")) {
      const days = parseInt(shop.offerExpiry);
      expiryDate = new Date(now.getTime() + days * 24 * 60 * 60 * 1000);
    } else {
      expiryDate = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    }
  }

  return (
    <div className="bg-white rounded-2xl shadow-md hover:shadow-lg p-4 w-[150px] relative transition-shadow duration-300 border border-neutral-light/20">
      {shop.isPartner && (
        <div className="absolute -top-2 -left-2 bg-primary/20 rounded-full p-1.5 shadow-sm">
          <Shield size={18} className="text-primary" />
        </div>
      )}
      
      {onToggleSave && (
        <button 
          className="absolute -top-2 -right-2 p-2 rounded-full bg-white shadow-md"
          onClick={handleToggleSave}
        >
          <Heart 
            size={18} 
            className={isSaved ? "text-red-500 fill-red-500" : "text-neutral-light"} 
          />
        </button>
      )}
      
      <div className="bg-neutral-light/10 rounded-xl p-3 mb-4 flex items-center justify-center h-[80px]">
        <img
          src={shop.logo}
          alt={shop.name}
          className="w-16 h-16 object-contain"
          onError={(e) => {
            // Fallback for broken images
            const target = e.target as HTMLImageElement;
            target.src = `https://ui-avatars.com/api/?name=${shop.name}&background=4A66E4&color=fff`;
          }}
        />
      </div>
      
      <h3 className="text-sm font-semibold mb-2 truncate text-center">{shop.name}</h3>
      
      {shop.savingsAmount && (
        <Badge variant="default" className="absolute -top-1 -right-1 bg-primary text-xs px-2.5 py-0.5 shadow-sm">
          Save {shop.savingsAmount}
        </Badge>
      )}
      
      {expiryDate && (
        <div className="mt-2">
          <OfferExpiryCountdown expiryDate={expiryDate} />
        </div>
      )}

      {shop.cardTypes && shop.cardTypes.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1 justify-center">
          {shop.cardTypes.map(card => (
            <Badge key={card} variant="outline" className="text-[10px] px-1 py-0">
              {card}
            </Badge>
          ))}
        </div>
      )}
    </div>
  );
};

export default ShopCard;
