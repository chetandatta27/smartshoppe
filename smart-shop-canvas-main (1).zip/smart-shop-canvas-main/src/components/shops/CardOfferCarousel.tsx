
import React, { useState } from "react";
import { ThumbsUp, ThumbsDown, Info } from "lucide-react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { Badge } from "@/components/ui/badge";
import { CardOffer } from "./ShopTypes";

interface CardOfferCarouselProps {
  cards: CardOffer[];
  onCardSelect?: (cardId: string) => void;
  selectedCardId?: string | null;
}

const CardOfferCarousel: React.FC<CardOfferCarouselProps> = ({
  cards,
  onCardSelect,
  selectedCardId,
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [userRatings, setUserRatings] = useState<Record<string, boolean | null>>({});
  
  const handleRateCard = (cardId: string, liked: boolean) => {
    setUserRatings({
      ...userRatings,
      [cardId]: liked,
    });
    
    // If this is a like and we have an onCardSelect handler, call it
    if (liked && onCardSelect) {
      onCardSelect(cardId);
    }
  };
  
  const handleCardClick = (cardId: string) => {
    if (onCardSelect) {
      onCardSelect(cardId);
    }
  };

  // Fixed: Handle the carousel API properly
  const handleCarouselSelect = (api: any) => {
    if (api && typeof api.selectedScrollSnap === 'function') {
      setActiveIndex(api.selectedScrollSnap());
    }
  };

  return (
    <Carousel
      className="w-full"
      opts={{
        align: "start",
      }}
      onSelect={(api) => handleCarouselSelect(api)}
    >
      <CarouselContent className="-ml-4">
        {cards.map((card, index) => (
          <CarouselItem key={card.id} className="pl-4 md:basis-1/2 lg:basis-1/3">
            <div
              className={`relative rounded-3xl shadow-md overflow-hidden h-[220px] cursor-pointer transition-all duration-300 ${
                selectedCardId === card.id ? "ring-2 ring-primary ring-offset-2" : ""
              }`}
              style={{
                background: `linear-gradient(135deg, ${card.color}40, ${card.color})`,
              }}
              onClick={() => handleCardClick(card.id)}
            >
              {card.badge && (
                <div className="absolute top-3 left-0 bg-primary text-white text-xs py-1 px-3 font-medium rounded-r-full">
                  {card.badge}
                </div>
              )}
              
              <div className="p-4 h-full flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div className="flex flex-col">
                    <h3 className="font-bold text-white text-lg">{card.bank}</h3>
                    <p className="text-white opacity-90 text-sm">{card.network}</p>
                  </div>
                  
                  <button className="text-white opacity-70 hover:opacity-100 transition bg-white/10 rounded-full p-1.5">
                    <Info size={18} />
                  </button>
                </div>
                
                <div className="my-4">
                  <div className="bg-white bg-opacity-20 p-4 rounded-xl backdrop-filter backdrop-blur-sm">
                    <p className="text-xs text-white mb-1">Cashback</p>
                    <p className="text-2xl font-bold text-white">{card.cashback}</p>
                  </div>
                </div>
                
                <div className="mb-1">
                  <p className="text-xs text-white mb-2">{card.offerDetails}</p>
                </div>
                
                <div className="flex justify-between">
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRateCard(card.id, true);
                    }}
                    className={`w-[48%] text-white backdrop-filter backdrop-blur-sm p-2 rounded-xl flex items-center justify-center transition ${
                      userRatings[card.id] === true ? 'bg-green-500 bg-opacity-80' : 'bg-white bg-opacity-20'
                    }`}
                  >
                    <ThumbsUp size={18} className="mr-1" />
                    <span className="text-sm">Like</span>
                  </button>
                  
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      handleRateCard(card.id, false);
                    }}
                    className={`w-[48%] text-white backdrop-filter backdrop-blur-sm p-2 rounded-xl flex items-center justify-center transition ${
                      userRatings[card.id] === false ? 'bg-red-500 bg-opacity-80' : 'bg-white bg-opacity-20'
                    }`}
                  >
                    <ThumbsDown size={18} className="mr-1" />
                    <span className="text-sm">Skip</span>
                  </button>
                </div>
              </div>
            </div>
          </CarouselItem>
        ))}
      </CarouselContent>
      <div className="flex justify-center mt-4">
        <CarouselPrevious className="relative static left-0 right-auto mx-2" />
        <div className="flex items-center gap-1">
          {cards.map((_, index) => (
            <div
              key={index}
              className={`w-2 h-2 rounded-full mx-0.5 ${
                activeIndex === index ? "bg-primary" : "bg-neutral-light"
              }`}
            />
          ))}
        </div>
        <CarouselNext className="relative static right-0 left-auto mx-2" />
      </div>
    </Carousel>
  );
};

export default CardOfferCarousel;
