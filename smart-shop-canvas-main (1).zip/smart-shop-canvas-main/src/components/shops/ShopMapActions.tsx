
import React from "react";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation } from "lucide-react";
import { ShopLocation } from "./ShopTypes";
import { toast } from "@/components/ui/use-toast";

interface ShopMapActionsProps {
  location?: ShopLocation;
  name: string;
  onViewMap: () => void;
  onGetDirections: () => void;
}

const ShopMapActions: React.FC<ShopMapActionsProps> = ({
  location,
  name,
  onViewMap,
  onGetDirections,
}) => {
  const handleGetDirections = () => {
    if (location) {
      onGetDirections();
    } else {
      toast({
        title: "Location not available",
        description: "We don't have the location information for this shop.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="mb-6 flex space-x-3">
      <Button 
        className="flex-1 gap-2" 
        variant="outline" 
        onClick={onViewMap}
      >
        <MapPin size={18} /> 
        View on Map
      </Button>
      <Button 
        className="flex-1 gap-2" 
        variant="outline" 
        onClick={handleGetDirections}
      >
        <Navigation size={18} />
        Get Directions
      </Button>
    </div>
  );
};

export default ShopMapActions;
