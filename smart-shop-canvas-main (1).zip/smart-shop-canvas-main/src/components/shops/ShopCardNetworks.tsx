
import React from "react";
import { Badge } from "@/components/ui/badge";

interface ShopCardNetworksProps {
  networks: string[];
  className?: string;
}

const ShopCardNetworks: React.FC<ShopCardNetworksProps> = ({ networks, className = "" }) => {
  // Function to get color based on network
  const getNetworkColor = (network: string) => {
    switch (network.toLowerCase()) {
      case "visa":
        return "bg-blue-50 text-blue-700 border-blue-100";
      case "mastercard":
        return "bg-red-50 text-red-700 border-red-100";
      case "rupay":
      case "rupay":
        return "bg-green-50 text-green-700 border-green-100";
      case "amex":
        return "bg-purple-50 text-purple-700 border-purple-100";
      default:
        return "bg-gray-50 text-gray-700 border-gray-100";
    }
  };

  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {networks.map((network) => (
        <Badge
          key={network}
          variant="outline"
          className={`${getNetworkColor(network)} text-xs py-0.5`}
        >
          {network}
        </Badge>
      ))}
    </div>
  );
};

export default ShopCardNetworks;
