
import React from "react";
import { ArrowLeft, Heart, MapPin } from "lucide-react";
import { useNavigate } from "react-router-dom";
import OfferExpiryCountdown from "@/components/offers/OfferExpiryCountdown";
import ShopCardNetworks from "@/components/shops/ShopCardNetworks";
import { toast } from "@/components/ui/use-toast";

interface ShopLocation {
  lat: number;
  lng: number;
}

interface ShopHeaderProps {
  shopId: string;
  name: string;
  logo: string;
  distance?: string;
  offerExpiry?: string;
  cardTypes?: string[];
  isSaved: boolean;
  onSaveToggle: () => void;
}

const ShopHeader: React.FC<ShopHeaderProps> = ({
  name,
  logo,
  distance,
  offerExpiry,
  cardTypes,
  isSaved,
  onSaveToggle,
}) => {
  const navigate = useNavigate();

  // Calculate expiry date for countdown if provided
  const expiryDate = new Date();
  if (offerExpiry) {
    expiryDate.setDate(expiryDate.getDate() + parseInt(offerExpiry));
  }

  return (
    <div className="sticky top-0 z-10 bg-white shadow-md">
      <div className="pt-12 pb-4 px-6">
        <div className="flex items-center mb-4">
          <button className="mr-3" onClick={() => navigate(-1)}>
            <ArrowLeft size={24} />
          </button>
          <h1 className="text-xl font-bold font-poppins">{name}</h1>
        </div>

        <div className="flex items-start justify-between">
          <div className="flex items-center">
            <div className="h-14 w-14 bg-neutral-light/10 rounded-lg p-2 mr-3 flex items-center justify-center">
              <img
                src={logo}
                alt={name}
                className="w-full h-full object-contain"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = `https://ui-avatars.com/api/?name=${name}&background=random`;
                }}
              />
            </div>
            <div>
              {distance && (
                <div className="flex items-center">
                  <MapPin size={14} className="text-neutral-medium mr-1" />
                  <span className="text-sm text-neutral-medium">{distance} away</span>
                </div>
              )}
              {offerExpiry && (
                <div className="mt-1">
                  <OfferExpiryCountdown expiryDate={expiryDate} />
                </div>
              )}
            </div>
          </div>

          <button
            className={`p-2 rounded-full ${isSaved ? 'bg-red-50' : 'bg-neutral-light/10'}`}
            onClick={onSaveToggle}
          >
            <Heart
              size={22}
              className={isSaved ? "text-red-500 fill-red-500" : "text-neutral-medium"}
            />
          </button>
        </div>

        {cardTypes && <ShopCardNetworks networks={cardTypes} className="mt-3" />}
      </div>
    </div>
  );
};

export default ShopHeader;
