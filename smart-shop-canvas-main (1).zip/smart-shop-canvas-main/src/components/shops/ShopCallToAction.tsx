
import React from "react";
import { Button } from "@/components/ui/button";

interface ShopCallToActionProps {
  onUseCard: () => void;
}

const ShopCallToAction: React.FC<ShopCallToActionProps> = ({ onUseCard }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white p-4 border-t border-neutral-light/20 flex space-x-3">
      <Button className="flex-1" variant="secondary" onClick={onUseCard}>
        I Used This Card
      </Button>
      <Button className="flex-1">Buy Now & Save</Button>
    </div>
  );
};

export default ShopCallToAction;
