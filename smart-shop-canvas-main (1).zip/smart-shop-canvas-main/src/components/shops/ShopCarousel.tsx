
import React, { useState } from "react";
import { motion } from "framer-motion";
import { ScrollArea } from "@/components/ui/scroll-area";
import ShopCard from "./ShopCard";
import { Badge } from "@/components/ui/badge";
import { Filter } from "lucide-react";
import { useNavigate } from "react-router-dom";

export type Shop = {
  id: string;
  name: string;
  logo: string;
  savingsAmount?: string;
  isPartner?: boolean;
  offerExpiry?: string; // "2 days", "5 hours", etc.
  cardTypes?: string[]; // "Visa", "Mastercard", etc.
  distance?: string;
  address?: string;
  location?: { lat: number; lng: number };
};

interface ShopCarouselProps {
  shops: Shop[];
  title: string;
  onShopSelect: (shopId: string) => void;
  savedShops?: string[];
  onToggleSaveShop?: (shopId: string) => void;
  showFilters?: boolean;
}

const ShopCarousel: React.FC<ShopCarouselProps> = ({ 
  shops, 
  title, 
  onShopSelect,
  savedShops = [],
  onToggleSaveShop,
  showFilters = false
}) => {
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const navigate = useNavigate();
  
  const filters = [
    { id: "all", name: "All" },
    { id: "partners", name: "Partners" },
    { id: "visa", name: "Visa" },
    { id: "mastercard", name: "Mastercard" },
    { id: "amex", name: "Amex" },
    { id: "rupay", name: "RuPay" }
  ];
  
  const filteredShops = shops.filter(shop => {
    if (!activeFilter || activeFilter === "all") return true;
    if (activeFilter === "partners") return shop.isPartner;
    if (shop.cardTypes) {
      return shop.cardTypes.some(
        cardType => cardType.toLowerCase() === activeFilter.toLowerCase()
      );
    }
    return false;
  });

  const handleShopClick = (shopId: string) => {
    onShopSelect(shopId);
    navigate(`/shop/${shopId}`);
  };

  return (
    <div className="py-6">
      <div className="flex justify-between items-center mb-5 px-6">
        <h2 className="text-lg font-bold font-poppins">{title}</h2>
        <button className="text-sm text-primary font-medium">View All</button>
      </div>

      {showFilters && (
        <div className="mb-5 px-6">
          <ScrollArea>
            <div className="flex gap-3 pb-3">
              {filters.map((filter) => (
                <Badge
                  key={filter.id}
                  variant={activeFilter === filter.id ? "default" : "outline"}
                  className="cursor-pointer py-2 px-4 text-sm"
                  onClick={() => setActiveFilter(
                    activeFilter === filter.id ? null : filter.id
                  )}
                >
                  {filter.id === "all" && activeFilter === null && (
                    <Filter size={14} className="mr-1.5" />
                  )}
                  {filter.name}
                </Badge>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      <ScrollArea className="pb-2">
        <div className="flex gap-5 px-6 overflow-x-auto scrollbar-hide pb-4">
          {filteredShops.map((shop, index) => (
            <motion.div
              key={shop.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1, duration: 0.3 }}
              className="flex-none"
              onClick={() => handleShopClick(shop.id)}
            >
              <ShopCard 
                shop={shop} 
                isSaved={savedShops.includes(shop.id)}
                onToggleSave={onToggleSaveShop}
              />
            </motion.div>
          ))}
          
          {filteredShops.length === 0 && (
            <div className="flex-1 py-12 text-center text-neutral-medium">
              <p>No shops match your filter</p>
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
};

export default ShopCarousel;
