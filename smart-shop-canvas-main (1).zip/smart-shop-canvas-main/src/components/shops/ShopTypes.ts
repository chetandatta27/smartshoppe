
export interface ShopLocation {
  lat: number;
  lng: number;
}

export interface Shop {
  id: string;
  name: string;
  logo: string;
  isPartner?: boolean;
  distance?: string;
  offerExpiry?: string;
  cardTypes?: string[];
  savingsAmount?: string;
  address?: string;
  location?: ShopLocation;
}

export interface CardOffer {
  id: string;
  bank: string;
  network: string;
  cashback: string;
  color: string;
  badge?: string;
  offerDetails?: string;  // Made optional
  minSpend?: string;      // Made optional
  cashbackCap?: string;   // Made optional
  processingTime?: string; // Made optional
  isUserCard?: boolean;   // Added to match some usages
}
