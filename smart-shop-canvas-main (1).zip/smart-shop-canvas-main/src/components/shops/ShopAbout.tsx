
import React from "react";
import { Shield } from "lucide-react";

interface ShopAboutProps {
  name: string;
  isPartner?: boolean;
  address?: string;
}

const ShopAbout: React.FC<ShopAboutProps> = ({ name, isPartner, address }) => {
  return (
    <div className="mb-8">
      <h2 className="text-lg font-bold mb-3 font-poppins">About {name}</h2>
      <div className="bg-neutral-light/10 rounded-xl p-4">
        {isPartner && (
          <div className="flex items-center mb-2">
            <Shield size={16} className="text-primary mr-1" />
            <span className="text-sm font-medium">Partner Shop</span>
          </div>
        )}
        {address && <p className="text-sm text-neutral-medium mb-2">{address}</p>}
        <p className="text-sm">
          Shop with confidence at {name} using your preferred card to earn rewards and cashback.
          Select a card from above to maximize your savings.
        </p>
      </div>
    </div>
  );
};

export default ShopAbout;
