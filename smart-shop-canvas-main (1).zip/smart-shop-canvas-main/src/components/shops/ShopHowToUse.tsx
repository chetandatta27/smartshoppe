
import React from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { CardOffer } from "./ShopTypes";

interface ShopHowToUseProps {
  selectedCard: string | null;
  cardOffers: CardOffer[];
  expiryDate: Date;
}

const ShopHowToUse: React.FC<ShopHowToUseProps> = ({
  selectedCard,
  cardOffers,
  expiryDate,
}) => {
  // Find the selected card
  const selectedCardDetails = selectedCard 
    ? cardOffers.find(card => card.id === selectedCard) 
    : null;

  return (
    <div className="mb-6">
      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="how-to-use">
          <AccordionTrigger className="font-bold py-3">How to Use This Offer</AccordionTrigger>
          <AccordionContent>
            <ol className="space-y-3 mb-3">
              <li className="flex items-start">
                <div className="bg-primary/10 rounded-full w-6 h-6 flex items-center justify-center mr-2 mt-0.5">
                  <span className="text-primary font-medium">1</span>
                </div>
                <div className="flex-1">
                  <p>Pay using your {selectedCardDetails ? selectedCardDetails.bank : 'selected'} card</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="bg-primary/10 rounded-full w-6 h-6 flex items-center justify-center mr-2 mt-0.5">
                  <span className="text-primary font-medium">2</span>
                </div>
                <div className="flex-1">
                  <p>Meet minimum spend of 
                    {selectedCardDetails && selectedCardDetails.minSpend
                      ? ` ${selectedCardDetails.minSpend}` 
                      : ' ₹500+'}
                  </p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="bg-primary/10 rounded-full w-6 h-6 flex items-center justify-center mr-2 mt-0.5">
                  <span className="text-primary font-medium">3</span>
                </div>
                <div className="flex-1">
                  <p>Cashback will be reflected in 
                    {selectedCardDetails && selectedCardDetails.processingTime
                      ? ` ${selectedCardDetails.processingTime}` 
                      : ' 3-5 days'}
                  </p>
                </div>
              </li>
            </ol>
            <p className="text-xs text-neutral-medium mt-3">
              * Cashback capped at 
              {selectedCardDetails && selectedCardDetails.cashbackCap
                ? ` ${selectedCardDetails.cashbackCap}` 
                : ' ₹200'} per transaction
            </p>
          </AccordionContent>
        </AccordionItem>
        
        <AccordionItem value="terms">
          <AccordionTrigger className="font-bold py-3">Terms & Conditions</AccordionTrigger>
          <AccordionContent>
            <ul className="space-y-2 text-sm">
              <li>• Offer valid until {expiryDate.toLocaleDateString()}</li>
              <li>• Not valid with other promotions</li>
              <li>• ShopSmart is not liable for merchant-end issues</li>
              <li>• Bank reserves the right to modify terms without notice</li>
            </ul>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
};

export default ShopHowToUse;
