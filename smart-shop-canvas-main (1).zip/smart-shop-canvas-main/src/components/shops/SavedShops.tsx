
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Clock } from "lucide-react";
import { motion } from "framer-motion";
import { type Shop } from "./ShopCarousel";

interface SavedShopsProps {
  savedShops: Shop[];
}

const SavedShops: React.FC<SavedShopsProps> = ({ savedShops }) => {
  if (savedShops.length === 0) {
    return (
      <div className="px-6 py-8 text-center">
        <div className="bg-neutral-light/20 p-8 rounded-xl">
          <Heart size={40} className="text-neutral-light mx-auto mb-4" />
          <p className="text-neutral-medium">No saved shops yet</p>
          <p className="text-xs text-neutral-medium mt-2">
            Tap the heart icon on any shop to save it
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="px-6 py-4">
      <h2 className="text-xl font-bold mb-4">Saved Shops</h2>
      
      <div className="space-y-3 mb-4">
        {savedShops.map((shop, index) => (
          <motion.div
            key={shop.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-hidden border-none shadow-soft">
              <CardContent className="p-0">
                <div className="flex items-center p-4">
                  <div className="bg-neutral-light/10 rounded-xl p-3 mr-4">
                    <img
                      src={shop.logo}
                      alt={shop.name}
                      className="w-10 h-10 object-contain"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement;
                        target.src = `https://ui-avatars.com/api/?name=${shop.name}&background=4A66E4&color=fff`;
                      }}
                    />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold">{shop.name}</h4>
                    <div className="flex items-center mt-1">
                      {shop.offerExpiry && (
                        <span className="flex items-center text-xs text-neutral-medium">
                          <Clock size={12} className="mr-1" />
                          Ends in {shop.offerExpiry}
                        </span>
                      )}
                    </div>
                  </div>
                  {shop.savingsAmount && (
                    <Badge className="bg-primary text-white">
                      Save {shop.savingsAmount}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default SavedShops;
