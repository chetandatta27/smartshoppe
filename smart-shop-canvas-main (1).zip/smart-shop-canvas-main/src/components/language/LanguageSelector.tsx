
import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";
import { Language } from "./LanguageTypes";

interface LanguageSelectorProps {
  currentLanguage: Language;
  languages: Language[];
  onSelectLanguage: (language: Language) => void;
  onClose: () => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLanguage,
  languages,
  onSelectLanguage,
  onClose
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <Card className="w-full max-w-xs mx-auto overflow-hidden">
        <CardHeader>
          <CardTitle className="text-lg">Select Language</CardTitle>
        </CardHeader>
        <CardContent className="pb-4">
          <div className="space-y-1">
            {languages.map((language) => (
              <div
                key={language.code}
                className={`
                  flex items-center justify-between p-3 rounded-lg cursor-pointer
                  ${currentLanguage.code === language.code ? 'bg-primary/10' : 'hover:bg-neutral-light/10'}
                `}
                onClick={() => {
                  onSelectLanguage(language);
                  onClose();
                }}
              >
                <div className="flex flex-col">
                  <span className="font-medium">{language.name}</span>
                  <span className="text-xs text-neutral-medium">{language.nativeName}</span>
                </div>
                {currentLanguage.code === language.code && (
                  <Check size={18} className="text-primary" />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default LanguageSelector;
