
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Home, MapPin, CreditCard, User, PhoneCall } from "lucide-react";

const BottomNavigation: React.FC = () => {
  const location = useLocation();
  const currentPath = location.pathname;

  const navItems = [
    {
      name: "Home",
      path: "/",
      icon: Home,
    },
    {
      name: "Rewards",
      path: "/rewards",
      icon: CreditCard,
    },
    {
      name: "Saved",
      path: "/saved-shops",
      icon: MapPin,
    },
    {
      name: "Contact",
      path: "/contact",
      icon: PhoneCall,
    },
    {
      name: "Profile",
      path: "/preferences",
      icon: User,
    },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-neutral-light shadow-md z-50">
      <nav className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = currentPath === item.path;
          return (
            <Link
              key={item.name}
              to={item.path}
              className={`flex flex-col items-center justify-center py-3 px-4 transition-colors ${
                isActive ? "text-primary" : "text-neutral-medium"
              }`}
            >
              <item.icon 
                size={22} 
                strokeWidth={isActive ? 2.5 : 1.8} 
                className={isActive ? "animate-scale-in" : ""}
              />
              <span className={`text-xs mt-1 ${isActive ? "font-medium" : ""}`}>
                {item.name}
              </span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default BottomNavigation;
