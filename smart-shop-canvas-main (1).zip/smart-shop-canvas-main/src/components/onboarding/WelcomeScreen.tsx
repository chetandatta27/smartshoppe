
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

interface WelcomeScreenProps {
  onContinue: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onContinue }) => {
  return (
    <div className="flex flex-col min-h-screen bg-white">
      <motion.div 
        className="flex-1 flex flex-col items-center justify-center px-6 text-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="mb-8">
          <motion.div 
            className="mb-6 flex justify-center"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <div className="w-56 h-56 rounded-full bg-blue-50 flex items-center justify-center">
              <div className="w-40 h-40 relative">
                {/* App Icon Illustration */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-secondary w-28 h-20 rounded-md flex items-center justify-center shadow-md">
                    <div className="bg-primary w-16 h-10 rounded-md flex items-center justify-center text-white font-poppins font-bold">
                      SAVE
                    </div>
                  </div>
                </div>
                <div className="absolute -right-4 -top-4">
                  <div className="bg-white shadow-soft p-1.5 rounded-full">
                    <div className="bg-primary text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shopping-cart"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.h1 
            className="text-3xl font-poppins font-bold mb-3"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            Welcome to ShopSmart
          </motion.h1>
          
          <motion.p 
            className="text-neutral-medium text-lg mb-8"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.7, duration: 0.8 }}
          >
            Make smarter financial choices at every shop
          </motion.p>
          
          <motion.div
            className="space-y-4"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.9, duration: 0.8 }}
          >
            <div className="flex items-center mb-3">
              <div className="bg-blue-50 p-2 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0D6EFD" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-credit-card"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>
              </div>
              <p className="text-left text-sm">Find the best card for each store</p>
            </div>
            <div className="flex items-center mb-3">
              <div className="bg-blue-50 p-2 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0D6EFD" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-percent"><line x1="19" x2="5" y1="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/></svg>
              </div>
              <p className="text-left text-sm">Get personalized cashback offers</p>
            </div>
            <div className="flex items-center">
              <div className="bg-blue-50 p-2 rounded-full mr-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0D6EFD" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-map-pin"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
              </div>
              <p className="text-left text-sm">Find savings near your location</p>
            </div>
          </motion.div>
        </div>
      </motion.div>

      <motion.div 
        className="p-6"
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 1.1, duration: 0.8 }}
      >
        <Button className="btn-primary w-full flex items-center justify-center" onClick={onContinue}>
          <span className="mr-2">Get Started</span> 
          <ArrowRight size={18} />
        </Button>
      </motion.div>
    </div>
  );
};

export default WelcomeScreen;
