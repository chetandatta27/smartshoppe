
import React, { useState, FormEvent } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight } from "lucide-react";

interface RegistrationFormProps {
  onSubmit: (phoneNumber: string, name: string) => void;
  onBack: () => void;
}

const RegistrationForm: React.FC<RegistrationFormProps> = ({ onSubmit, onBack }) => {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [name, setName] = useState("");
  const [errors, setErrors] = useState({ phone: "", name: "" });

  const validateForm = (): boolean => {
    let valid = true;
    const newErrors = { phone: "", name: "" };

    if (!phoneNumber.trim()) {
      newErrors.phone = "Phone number is required";
      valid = false;
    } else if (!/^\+?[0-9]{10,15}$/.test(phoneNumber.replace(/\s+/g, ""))) {
      newErrors.phone = "Please enter a valid phone number";
      valid = false;
    }

    if (!name.trim()) {
      newErrors.name = "Name is required";
      valid = false;
    }

    setErrors(newErrors);
    return valid;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(phoneNumber, name);
    }
  };

  return (
    <motion.div 
      className="min-h-screen flex flex-col bg-white p-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-8">
        <button 
          onClick={onBack} 
          className="mb-4 text-neutral-medium flex items-center"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left mr-1"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
          Back
        </button>
        <h1 className="text-2xl font-bold font-poppins mb-2">Create your account</h1>
        <p className="text-neutral-medium">Let's get you started with ShopSmart</p>
      </div>

      <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
        <div className="flex-1 space-y-6">
          <motion.div 
            className="input-container"
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.1, duration: 0.5 }}
          >
            <Label htmlFor="phone" className="input-label">Phone number</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+1 (555) 123-4567"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className={`w-full ${errors.phone ? 'border-red-500 focus:ring-red-300' : ''}`}
            />
            {errors.phone && (
              <p className="text-red-500 text-xs mt-1">{errors.phone}</p>
            )}
            <p className="text-xs text-neutral-medium mt-1">
              We'll send a verification code to this number
            </p>
          </motion.div>

          <motion.div 
            className="input-container"
            initial={{ x: 20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <Label htmlFor="name" className="input-label">Full name</Label>
            <Input
              id="name"
              type="text"
              placeholder="John Doe"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className={`w-full ${errors.name ? 'border-red-500 focus:ring-red-300' : ''}`}
            />
            {errors.name && (
              <p className="text-red-500 text-xs mt-1">{errors.name}</p>
            )}
          </motion.div>
        </div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <Button type="submit" className="btn-primary w-full mt-6 flex items-center justify-center">
            <span className="mr-2">Continue</span>
            <ArrowRight size={18} />
          </Button>
          <p className="text-center text-xs text-neutral-medium mt-4">
            By continuing, you agree to ShopSmart's <a href="#" className="text-primary">Terms of Service</a> and <a href="#" className="text-primary">Privacy Policy</a>
          </p>
        </motion.div>
      </form>
    </motion.div>
  );
};

export default RegistrationForm;
