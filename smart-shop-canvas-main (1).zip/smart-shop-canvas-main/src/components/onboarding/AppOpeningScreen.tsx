
import React, { useEffect } from "react";
import { motion } from "framer-motion";
import { MapPin } from "lucide-react";

interface AppOpeningScreenProps {
  onComplete: () => void;
}

const AppOpeningScreen: React.FC<AppOpeningScreenProps> = ({ onComplete }) => {
  useEffect(() => {
    // Auto-dismiss after animation completes
    const timer = setTimeout(() => {
      onComplete();
    }, 2500);
    
    return () => clearTimeout(timer);
  }, [onComplete]);
  
  return (
    <motion.div 
      className="fixed inset-0 z-50 bg-primary flex flex-col items-center justify-center"
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ 
          duration: 0.8,
          ease: [0.2, 0.8, 0.2, 1]
        }}
        className="text-center"
      >
        <div className="flex justify-center mb-4">
          <motion.div 
            className="bg-white rounded-full p-4"
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, -10, 10, -10, 0] 
            }}
            transition={{ 
              duration: 1.5,
              ease: "easeInOut",
              times: [0, 0.2, 0.5, 0.8, 1],
              repeat: 0
            }}
          >
            <MapPin size={48} className="text-primary" />
          </motion.div>
        </div>
        
        <motion.h1 
          className="text-3xl font-bold text-white mb-2"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          ShopSmart
        </motion.h1>
        
        <motion.p 
          className="text-white/80 text-sm"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          Find the best deals near you
        </motion.p>
        
        <motion.div 
          className="mt-8 flex justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7, duration: 0.5 }}
        >
          <div className="flex space-x-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                className="w-3 h-3 bg-white rounded-full"
                animate={{ 
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{ 
                  duration: 1,
                  repeat: Infinity,
                  repeatType: "reverse",
                  delay: i * 0.2
                }}
              />
            ))}
          </div>
        </motion.div>
      </motion.div>
    </motion.div>
  );
};

export default AppOpeningScreen;
