
import React, { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowRight } from "lucide-react";

interface VerificationScreenProps {
  phoneNumber: string;
  onVerify: () => void;
  onBack: () => void;
}

const VerificationScreen: React.FC<VerificationScreenProps> = ({ phoneNumber, onVerify, onBack }) => {
  const [code, setCode] = useState(["", "", "", "", "", ""]);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const [isValidating, setIsValidating] = useState(false);
  const [error, setError] = useState("");
  const [resendDisabled, setResendDisabled] = useState(true);
  const [resendTimer, setResendTimer] = useState(30);

  useEffect(() => {
    // Focus first input on mount
    if (inputRefs.current[0]) {
      inputRefs.current[0].focus();
    }
    
    // Start countdown for resend button
    const timer = setInterval(() => {
      setResendTimer((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setResendDisabled(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleInputChange = (index: number, value: string) => {
    // Only accept numbers
    if (value !== "" && !/^[0-9]$/.test(value)) return;

    setError("");
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);

    // Auto focus next input
    if (value !== "" && index < 5) {
      if (inputRefs.current[index + 1]) {
        inputRefs.current[index + 1].focus();
      }
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && code[index] === "" && index > 0) {
      // Focus previous input on backspace if current is empty
      if (inputRefs.current[index - 1]) {
        inputRefs.current[index - 1].focus();
      }
    }
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pasteData = e.clipboardData.getData("text").slice(0, 6);
    if (!/^\d+$/.test(pasteData)) return;

    const newCode = [...code];
    for (let i = 0; i < pasteData.length; i++) {
      if (i < 6) {
        newCode[i] = pasteData[i];
      }
    }
    setCode(newCode);

    // Focus the input after the last pasted digit
    const lastIndex = Math.min(pasteData.length - 1, 5);
    if (pasteData.length < 6 && inputRefs.current[lastIndex]) {
      inputRefs.current[lastIndex].focus();
    }
  };

  const handleSubmit = async () => {
    if (code.join("").length !== 6) {
      setError("Please enter the complete code");
      return;
    }

    setIsValidating(true);
    
    // Simulate verification API call
    setTimeout(() => {
      setIsValidating(false);
      
      // Simple demo validation - any code with 6 digits works
      if (code.join("").length === 6) {
        onVerify();
      } else {
        setError("Invalid verification code");
      }
    }, 1500);
  };

  const handleResendCode = () => {
    // Reset timer
    setResendDisabled(true);
    setResendTimer(30);
    
    // Simulate resending code
    setTimeout(() => {
      // Start countdown again
      const timer = setInterval(() => {
        setResendTimer((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setResendDisabled(false);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }, 500);
  };

  return (
    <motion.div 
      className="min-h-screen flex flex-col bg-white p-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.4 }}
    >
      <div className="mb-8">
        <button 
          onClick={onBack} 
          className="mb-4 text-neutral-medium flex items-center"
          disabled={isValidating}
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-arrow-left mr-1"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>
          Back
        </button>
        <h1 className="text-2xl font-bold font-poppins mb-2">Verify your number</h1>
        <p className="text-neutral-medium">
          Enter the 6-digit code sent to <span className="text-neutral-dark">{phoneNumber}</span>
        </p>
      </div>

      <div className="flex-1">
        <div className="flex justify-between mb-4 gap-2">
          {code.map((digit, index) => (
            <motion.div
              key={index}
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: index * 0.05, duration: 0.3 }}
              className="w-full"
            >
              <Input
                type="text"
                ref={(el) => (inputRefs.current[index] = el)}
                className={`w-full aspect-square text-center text-xl font-medium ${
                  error ? 'border-red-500 focus:ring-red-300' : 'border-neutral-light'
                }`}
                maxLength={1}
                value={digit}
                onChange={(e) => handleInputChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onPaste={index === 0 ? handlePaste : undefined}
                disabled={isValidating}
              />
            </motion.div>
          ))}
        </div>

        {error && (
          <motion.p 
            className="text-red-500 text-center mb-4" 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            {error}
          </motion.p>
        )}

        <motion.div 
          className="text-center mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <button
            onClick={handleResendCode}
            disabled={resendDisabled}
            className={`text-sm ${
              resendDisabled
                ? "text-neutral-light cursor-not-allowed"
                : "text-primary hover:underline"
            }`}
          >
            {resendDisabled ? `Resend code in ${resendTimer}s` : "Resend code"}
          </button>
        </motion.div>
      </div>

      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3, duration: 0.5 }}
      >
        <Button 
          className="btn-primary w-full flex items-center justify-center" 
          onClick={handleSubmit}
          disabled={code.join("").length !== 6 || isValidating}
        >
          {isValidating ? (
            <div className="flex items-center">
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
              Verifying...
            </div>
          ) : (
            <>
              <span className="mr-2">Verify and Continue</span>
              <ArrowRight size={18} />
            </>
          )}
        </Button>
      </motion.div>
    </motion.div>
  );
};

export default VerificationScreen;
