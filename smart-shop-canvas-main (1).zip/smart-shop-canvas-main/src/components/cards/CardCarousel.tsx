
import React, { useState } from "react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { CardOffer } from "@/components/shops/ShopTypes";
import CardItem from "./CardItem";
import { Badge } from "@/components/ui/badge";
import { CreditCard } from "lucide-react";
import { motion } from "framer-motion";

interface CardCarouselProps {
  cards: CardOffer[];
  title: string;
  description?: string;
  showPersonalizedToggle?: boolean;
  onTogglePersonalized?: (show: boolean) => void;
}

const CardCarousel: React.FC<CardCarouselProps> = ({
  cards,
  title,
  description,
  showPersonalizedToggle = false,
  onTogglePersonalized,
}) => {
  const [showPersonalized, setShowPersonalized] = useState(false);

  const handleToggle = () => {
    setShowPersonalized(!showPersonalized);
    if (onTogglePersonalized) {
      onTogglePersonalized(!showPersonalized);
    }
  };

  return (
    <div className="py-6">
      <div className="flex justify-between items-center mb-4 px-6">
        <h2 className="text-lg font-bold font-poppins">{title}</h2>
        {description && (
          <p className="text-sm text-neutral-medium">{description}</p>
        )}
      </div>

      <ScrollArea className="pb-2">
        <div className="flex gap-4 px-6 overflow-x-auto scrollbar-hide pb-4">
          {cards.map((card, index) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1, duration: 0.3 }}
              className="flex-none"
            >
              <CardItem card={card} />
            </motion.div>
          ))}
        </div>
      </ScrollArea>

      {showPersonalizedToggle && (
        <div className="px-6 mt-4">
          <Badge
            variant={showPersonalized ? "default" : "outline"}
            onClick={handleToggle}
            className="cursor-pointer"
          >
            {showPersonalized ? "Showing My Cards" : "Personalize"}
          </Badge>
        </div>
      )}
    </div>
  );
};

export default CardCarousel;
