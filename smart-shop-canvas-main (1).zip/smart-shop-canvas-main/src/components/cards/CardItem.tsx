
import React, { useState } from "react";
import { motion } from "framer-motion";
import { CardOffer } from "@/components/shops/ShopTypes";
import { ThumbsUp, ThumbsDown, Info } from "lucide-react";

interface CardItemProps {
  card: CardOffer;
  onSelect?: () => void;
  selected?: boolean;
}

const CardItem: React.FC<CardItemProps> = ({ card, onSelect, selected }) => {
  const [liked, setLiked] = useState<boolean | null>(null);
  
  const handleLike = (e: React.MouseEvent, isLike: boolean) => {
    e.stopPropagation();
    setLiked(isLike ? true : false);
  };

  return (
    <div 
      className="relative rounded-3xl shadow-card overflow-hidden h-48 transition duration-300 hover:shadow-lg"
      style={{
        background: card.isUserCard 
          ? `linear-gradient(135deg, ${card.color}40, ${card.color})` 
          : `linear-gradient(135deg, #4A66E420, #4A66E4)`,
      }}
    >
      {card.badge && (
        <div className="absolute top-3 left-0 bg-primary text-white text-xs py-1 px-3 font-medium rounded-r-full">
          {card.badge}
        </div>
      )}
      
      {card.isUserCard && (
        <div className="absolute top-3 left-0 bg-secondary text-primary text-xs py-1 px-3 font-medium rounded-r-full">
          Your Card
        </div>
      )}
      
      <div className="p-4 h-full flex flex-col justify-between">
        <div className="flex justify-between">
          <div className="flex flex-col justify-center">
            <h3 className="font-bold text-white text-lg font-poppins">{card.bank}</h3>
            <p className="text-white opacity-90 text-sm">{card.network}</p>
          </div>
          
          <button className="text-white opacity-70 hover:opacity-100 transition">
            <Info size={18} />
          </button>
        </div>
        
        <div className="mb-2">
          <div className="bg-white bg-opacity-20 p-3 rounded-xl backdrop-filter backdrop-blur-sm">
            <p className="text-xs text-white mb-1">Cashback</p>
            <p className="text-xl font-bold text-white">{card.cashback}</p>
          </div>
        </div>
        
        <div className="flex justify-between">
          <button 
            onClick={(e) => handleLike(e, true)}
            className={`w-[48%] text-white backdrop-filter backdrop-blur-sm p-2 rounded-xl flex items-center justify-center transition ${
              liked === true ? 'bg-green-500 bg-opacity-80' : 'bg-white bg-opacity-20'
            }`}
          >
            <ThumbsUp size={18} className="mr-1" />
            <span className="text-sm">Like</span>
          </button>
          
          <button 
            onClick={(e) => handleLike(e, false)}
            className={`w-[48%] text-white backdrop-filter backdrop-blur-sm p-2 rounded-xl flex items-center justify-center transition ${
              liked === false ? 'bg-red-500 bg-opacity-80' : 'bg-white bg-opacity-20'
            }`}
          >
            <ThumbsDown size={18} className="mr-1" />
            <span className="text-sm">Skip</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default CardItem;
