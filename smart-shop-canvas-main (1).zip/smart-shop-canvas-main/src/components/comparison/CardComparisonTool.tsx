
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { X, BarChart2, Check, Info } from "lucide-react";
import { motion } from "framer-motion";
import { CardOffer } from "../shops/ShopTypes";

interface CardComparisonToolProps {
  cards: CardOffer[];
  onClose: () => void;
}

const CardComparisonTool: React.FC<CardComparisonToolProps> = ({ cards, onClose }) => {
  const [selectedCards, setSelectedCards] = useState<CardOffer[]>(cards.slice(0, Math.min(3, cards.length)));
  const [selectedCategory, setSelectedCategory] = useState<string>("cashback");

  const categories = [
    { name: "Cashback", key: "cashback", max: 5 },
    { name: "Annual Fee", key: "annualFee", max: 5000, lowerIsBetter: true },
    { name: "Reward Points", key: "rewardPoints", max: 10 },
    { name: "International Usage", key: "internationalUsage", max: 5 },
  ];

  // Mock data for comparison metrics
  const cardMetrics = {
    "1": { cashback: 5, annualFee: 1000, rewardPoints: 8, internationalUsage: 4 },
    "2": { cashback: 3, annualFee: 500, rewardPoints: 5, internationalUsage: 3 },
    "3": { cashback: 4, annualFee: 2000, rewardPoints: 7, internationalUsage: 5 },
    "4": { cashback: 2, annualFee: 0, rewardPoints: 6, internationalUsage: 2 },
    "5": { cashback: 5, annualFee: 1500, rewardPoints: 9, internationalUsage: 4 },
    "my1": { cashback: 5, annualFee: 1200, rewardPoints: 7, internationalUsage: 3 },
    "my2": { cashback: 3, annualFee: 800, rewardPoints: 6, internationalUsage: 4 },
  };
  
  const handleSelectCategory = (key: string) => {
    setSelectedCategory(key);
  };

  const getBestCard = () => {
    let bestCard = selectedCards[0];
    let bestValue = cardMetrics[selectedCards[0].id]?.[selectedCategory as keyof typeof cardMetrics["1"]] || 0;
    
    selectedCards.forEach(card => {
      const currentValue = cardMetrics[card.id]?.[selectedCategory as keyof typeof cardMetrics["1"]] || 0;
      const isBetter = categories.find(c => c.key === selectedCategory)?.lowerIsBetter
        ? currentValue < bestValue
        : currentValue > bestValue;
        
      if (isBetter) {
        bestCard = card;
        bestValue = currentValue;
      }
    });
    
    return bestCard.id;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <Card className="w-full max-w-md mx-auto overflow-hidden bg-white dark:bg-slate-800 rounded-xl shadow-xl border-0">
        <CardHeader className="relative pb-2 bg-gradient-to-r from-primary/5 to-primary/10">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={onClose} 
            className="absolute right-2 top-2 rounded-full hover:bg-white/20"
          >
            <X size={20} />
          </Button>
          <CardTitle className="text-xl flex items-center">
            <BarChart2 className="mr-2 text-primary" size={20} />
            Compare Cards
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-0">
          <div className="p-4 pt-2 bg-gradient-to-r from-primary/5 to-primary/10">
            <div className="grid grid-cols-3 gap-3">
              {selectedCards.map((card) => (
                <div 
                  key={card.id}
                  className="flex flex-col items-center text-center p-3 rounded-xl bg-white dark:bg-slate-700 shadow-md transition-all hover:shadow-lg"
                  style={{ 
                    borderTop: `3px solid ${card.color}`,
                    borderTopLeftRadius: '0.5rem',
                    borderTopRightRadius: '0.5rem' 
                  }}
                >
                  <p className="font-semibold text-sm mb-1 truncate w-full">{card.bank}</p>
                  <p className="text-xs text-neutral-medium mb-1">{card.network}</p>
                  <Badge variant="outline" className="text-xs bg-primary/10">{card.cashback}</Badge>
                </div>
              ))}
            </div>
          </div>
          
          <div className="p-4">
            <div className="flex space-x-2 flex-wrap gap-2 mb-4">
              {categories.map((category) => (
                <Badge 
                  key={category.key} 
                  variant={selectedCategory === category.key ? "default" : "outline"}
                  className="cursor-pointer"
                  onClick={() => handleSelectCategory(category.key)}
                >
                  {category.name}
                </Badge>
              ))}
            </div>
            
            <div className="space-y-6">
              {selectedCards.map((card) => {
                const value = cardMetrics[card.id]?.[selectedCategory as keyof typeof cardMetrics["1"]] || 0;
                const category = categories.find(c => c.key === selectedCategory);
                const percentage = category?.lowerIsBetter 
                  ? 100 - (value / category.max * 100)
                  : (value / category.max * 100);
                const isBest = card.id === getBestCard();
                
                return (
                  <div key={`${card.id}-${selectedCategory}`} className="relative">
                    <div className="flex items-center mb-1">
                      <div 
                        className="w-3 h-3 rounded-full mr-2"
                        style={{ backgroundColor: card.color }}
                      ></div>
                      <span className="text-sm font-medium">{card.bank}</span>
                      {isBest && (
                        <Badge className="ml-auto text-xs bg-green-500 text-white">
                          <Check size={10} className="mr-1" /> Best
                        </Badge>
                      )}
                    </div>
                    <div className="h-2 bg-neutral-light/30 dark:bg-neutral-dark/30 rounded-full overflow-hidden">
                      <div 
                        className="h-full rounded-full transition-all duration-500 ease-out"
                        style={{ 
                          width: `${percentage}%`,
                          backgroundColor: isBest ? '#22c55e' : card.color
                        }}
                      />
                    </div>
                    <div className="flex justify-between mt-1">
                      <p className="text-xs text-neutral-medium">
                        {selectedCategory === "annualFee" ? `₹${value}` : value}
                      </p>
                      <button className="text-xs text-primary flex items-center">
                        <Info size={10} className="mr-1" /> Details
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="p-4 pt-0">
            <Button 
              className="w-full mt-6 gap-2" 
              variant="default"
            >
              <Check size={16} />
              Select Best Card
            </Button>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default CardComparisonTool;
