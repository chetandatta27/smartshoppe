
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Award, Calendar, TrendingUp } from "lucide-react";

interface RewardsMetric {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
}

const RewardsTracker: React.FC = () => {
  const rewardsData: RewardsMetric[] = [
    {
      title: "Total Savings",
      value: "₹1,245",
      change: 12,
      icon: <Award size={20} className="text-primary" />,
    },
    {
      title: "This Month",
      value: "₹380",
      change: 5,
      icon: <Calendar size={20} className="text-primary" />,
    },
    {
      title: "Reward Points",
      value: "2,430",
      change: 8,
      icon: <TrendingUp size={20} className="text-primary" />,
    },
  ];

  const recentTransactions = [
    { shop: "Amazon", date: "May 10", savings: "₹120", card: "HDFC Visa" },
    { shop: "Starbucks", date: "May 8", savings: "₹45", card: "Amex" },
    { shop: "Walmart", date: "May 5", savings: "₹85", card: "Citi" },
  ];

  return (
    <div className="px-6 py-4">
      <h2 className="text-xl font-bold mb-4">Rewards Tracker</h2>
      
      <div className="grid grid-cols-3 gap-3 mb-6">
        {rewardsData.map((metric, index) => (
          <motion.div
            key={metric.title}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-soft p-3"
          >
            <div className="flex justify-between items-start mb-1">
              <div className="p-2 rounded-full bg-primary/10">
                {metric.icon}
              </div>
              {metric.change > 0 && (
                <Badge className="bg-green-100 text-green-800 text-xs">+{metric.change}%</Badge>
              )}
            </div>
            <p className="text-xs text-neutral-medium mt-2">{metric.title}</p>
            <p className="text-lg font-bold mt-1">{metric.value}</p>
          </motion.div>
        ))}
      </div>
      
      <Card className="mb-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Recent Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {recentTransactions.map((transaction, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.1 + 0.3 }}
                className="flex justify-between items-center py-2 border-b border-neutral-light/20 last:border-0"
              >
                <div>
                  <p className="font-medium text-sm">{transaction.shop}</p>
                  <p className="text-xs text-neutral-medium">{transaction.date}</p>
                </div>
                <div className="text-right">
                  <p className="font-medium text-sm text-green-600">{transaction.savings}</p>
                  <p className="text-xs text-neutral-medium">{transaction.card}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
      
      <p className="text-center text-xs text-neutral-medium">
        Connect your bank statements for more accurate tracking
      </p>
    </div>
  );
};

export default RewardsTracker;
