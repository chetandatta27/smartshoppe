
import React, { useState } from "react";
import BottomNavigation from "../components/layout/BottomNavigation";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ChevronDown, Plus, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const CARD_NETWORKS = [
  { id: "visa", name: "Visa" },
  { id: "mastercard", name: "Mastercard" },
  { id: "amex", name: "American Express" },
  { id: "discover", name: "Discover" },
];

const BANKS = [
  "SBI",
  "HDFC",
  "ICICI",
  "Axis Bank",
  "Bank of Baroda",
  "Punjab National Bank",
  "Canara Bank",
  "Yes Bank",
];

interface SavedCard {
  id: string;
  network: string;
  bank: string;
}

const Preferences: React.FC = () => {
  const [savedCards, setSavedCards] = useState<SavedCard[]>([
    { id: "card1", network: "Visa", bank: "HDFC" },
    { id: "card2", network: "Mastercard", bank: "SBI" },
  ]);
  const [isAddCardDialogOpen, setIsAddCardDialogOpen] = useState(false);
  const [selectedNetwork, setSelectedNetwork] = useState<string>("");
  const [selectedBank, setSelectedBank] = useState("");
  const [bankSearchOpen, setBankSearchOpen] = useState(false);
  const [bankSearchQuery, setBankSearchQuery] = useState("");
  const [selectedRewards, setSelectedRewards] = useState<string[]>(["cashback"]);
  const { toast } = useToast();

  const filteredBanks = BANKS.filter((bank) =>
    bank.toLowerCase().includes(bankSearchQuery.toLowerCase())
  );

  const handleRewardTypeToggle = (rewardType: string) => {
    setSelectedRewards((prev) => 
      prev.includes(rewardType)
        ? prev.filter(type => type !== rewardType)
        : [...prev, rewardType]
    );
  };

  const handleSavePreferences = () => {
    toast({
      title: "Preferences Saved",
      description: "Your preferences have been updated",
    });
  };

  const handleAddCard = () => {
    if (!selectedNetwork || !selectedBank) {
      toast({
        title: "Error",
        description: "Please select both card network and bank",
        variant: "destructive",
      });
      return;
    }

    const newCard: SavedCard = {
      id: `card${Date.now()}`,
      network: selectedNetwork,
      bank: selectedBank,
    };

    setSavedCards((prev) => [...prev, newCard]);
    setIsAddCardDialogOpen(false);
    setSelectedNetwork("");
    setSelectedBank("");

    toast({
      title: "Card Added",
      description: "Your new card has been added to preferences",
    });
  };

  const handleDeleteCard = (cardId: string) => {
    setSavedCards(savedCards.filter(card => card.id !== cardId));
    toast({
      title: "Card Removed",
      description: "Card has been removed from your preferences",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <div className="sticky top-0 z-10 bg-white shadow-md">
        <div className="pt-6 pb-4 px-6">
          <h1 className="text-xl font-bold text-gray-800 font-poppins">ShopSmart</h1>
          <div className="flex items-center mt-2">
            <Input placeholder="Search location..." className="rounded-full pl-8" />
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="mb-6">
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-lg font-bold">Top Credit Cards</h2>
            <Button variant="ghost" size="sm" className="flex items-center">
              Filter <ChevronDown size={16} className="ml-1" />
            </Button>
          </div>
          
          {/* Example card in the wireframe */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-4">
            <div className="flex justify-between items-start">
              <div className="flex gap-3">
                <div className="w-12 h-12 bg-gray-200 rounded-full"></div>
                <div>
                  <h3 className="font-medium">Card Name</h3>
                  <p className="text-sm text-gray-500">Brief description of the card</p>
                  <div className="mt-1">
                    <span className="text-sm font-medium text-blue-600">5% Cashback on Shopping</span>
                  </div>
                </div>
              </div>
              <button className="text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path>
                </svg>
              </button>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <h2 className="text-lg font-bold mb-4">Your Preferences</h2>
          
          <div className="mb-4">
            <h3 className="mb-2 font-medium">Reward Types</h3>
            <div className="flex flex-col gap-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="cashback" 
                  checked={selectedRewards.includes("cashback")}
                  onCheckedChange={() => handleRewardTypeToggle("cashback")}
                />
                <Label htmlFor="cashback">Cashback</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="emi" 
                  checked={selectedRewards.includes("emi")}
                  onCheckedChange={() => handleRewardTypeToggle("emi")}
                />
                <Label htmlFor="emi">EMI</Label>
              </div>
            </div>
          </div>
          
          <div className="mb-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="font-medium">Your Cards</h3>
              <Dialog open={isAddCardDialogOpen} onOpenChange={setIsAddCardDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="sm" className="p-1 h-auto">
                    <Plus size={18} />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add a New Card</DialogTitle>
                    <DialogDescription>
                      Add your card network and bank information
                    </DialogDescription>
                  </DialogHeader>
                  
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <Label htmlFor="card-network">Card Network</Label>
                      <div className="grid grid-cols-2 gap-2">
                        {CARD_NETWORKS.map((network) => (
                          <div 
                            key={network.id} 
                            className={`flex items-center gap-2 border rounded-md p-3 cursor-pointer hover:bg-gray-50 ${
                              selectedNetwork === network.name ? "border-blue-500 bg-blue-50" : "border-gray-200"
                            }`}
                            onClick={() => setSelectedNetwork(network.name)}
                          >
                            <div className="w-8 h-8 bg-gray-200 rounded-full"></div>
                            <span>{network.name}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="bank">Bank</Label>
                      <Popover open={bankSearchOpen} onOpenChange={setBankSearchOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={bankSearchOpen}
                            className="w-full justify-between"
                          >
                            {selectedBank ? selectedBank : "Select bank..."}
                            <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-[200px] p-0">
                          <Command>
                            <CommandInput
                              placeholder="Search bank..."
                              value={bankSearchQuery}
                              onValueChange={setBankSearchQuery}
                            />
                            <CommandEmpty>No bank found.</CommandEmpty>
                            <CommandGroup>
                              {filteredBanks.map((bank) => (
                                <CommandItem
                                  key={bank}
                                  value={bank}
                                  onSelect={(currentValue) => {
                                    setSelectedBank(currentValue);
                                    setBankSearchOpen(false);
                                  }}
                                >
                                  {bank}
                                </CommandItem>
                              ))}
                            </CommandGroup>
                          </Command>
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" onClick={() => setIsAddCardDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleAddCard}>Add Card</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            {savedCards.length > 0 ? (
              <div className="space-y-2">
                {savedCards.map((card) => (
                  <div key={card.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-md">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                        <span className="font-bold text-sm">{card.network.substring(0, 1)}</span>
                      </div>
                      <div>
                        <p className="font-medium">{card.network}</p>
                        <p className="text-sm text-gray-500">{card.bank}</p>
                      </div>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="p-0 h-8 w-8" 
                      onClick={() => handleDeleteCard(card.id)}
                    >
                      <X size={16} />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-6 flex flex-col items-center justify-center border border-dashed border-gray-300 rounded-md">
                <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mb-2">
                  <Plus size={24} className="text-gray-400" />
                </div>
                <p className="text-gray-500">Add your first card</p>
              </div>
            )}
          </div>
          
          <div className="mb-4">
            <h3 className="mb-2 font-medium">Financial Institutions</h3>
            <div className="flex flex-col gap-2">
              {BANKS.slice(0, 3).map((bank, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Checkbox 
                    id={`bank-${index}`} 
                    checked={savedCards.some(card => card.bank === bank)}
                  />
                  <Label htmlFor={`bank-${index}`}>{bank}</Label>
                </div>
              ))}
            </div>
          </div>
          
          <Button 
            className="w-full bg-gray-800 hover:bg-gray-900 text-white"
            onClick={handleSavePreferences}
          >
            Save Preferences
          </Button>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default Preferences;
