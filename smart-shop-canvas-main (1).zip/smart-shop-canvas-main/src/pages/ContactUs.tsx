
import React, { useState, FormEvent } from "react";
import BottomNavigation from "../components/layout/BottomNavigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MessageCircle, Mail, Send } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ContactUs: React.FC = () => {
  const [form, setForm] = useState({
    subject: "",
    name: "",
    phone: "",
    message: "",
  });
  const [errors, setErrors] = useState({
    subject: "",
    name: "",
    phone: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const validateForm = (): boolean => {
    const newErrors = {
      subject: "",
      name: "",
      phone: "",
      message: "",
    };
    let isValid = true;

    if (!form.subject.trim()) {
      newErrors.subject = "Subject is required";
      isValid = false;
    }

    if (!form.name.trim()) {
      newErrors.name = "Name is required";
      isValid = false;
    }

    if (!form.phone.trim()) {
      newErrors.phone = "Phone number is required";
      isValid = false;
    } else if (!/^\+?[0-9]{10,15}$/.test(form.phone.replace(/\s+/g, ""))) {
      newErrors.phone = "Please enter a valid phone number";
      isValid = false;
    }

    if (!form.message.trim()) {
      newErrors.message = "Message is required";
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: value,
    });
    // Clear error when typing
    if (errors[name as keyof typeof errors]) {
      setErrors({
        ...errors,
        [name]: "",
      });
    }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setIsSubmitting(true);
      
      // Simulate API call
      setTimeout(() => {
        setIsSubmitting(false);
        toast({
          title: "Message sent",
          description: "We'll get back to you as soon as possible.",
        });
        setForm({
          subject: "",
          name: "",
          phone: "",
          message: "",
        });
      }, 1500);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      <div className="sticky top-0 z-10 bg-primary shadow-md">
        <div className="pt-12 pb-4 px-6">
          <h1 className="text-xl font-bold text-white font-poppins">Contact Us</h1>
        </div>
      </div>

      <div className="p-6">
        <div className="bg-white shadow-soft rounded-xl p-6 mb-6">
          <div className="flex items-center mb-6">
            <div className="bg-blue-50 p-3 rounded-full mr-4">
              <MessageCircle size={24} className="text-primary" />
            </div>
            <div>
              <h2 className="font-poppins font-medium">Get in touch</h2>
              <p className="text-sm text-neutral-medium">
                We'd love to hear from you
              </p>
            </div>
          </div>

          <form onSubmit={handleSubmit}>
            <div className="space-y-4">
              <div className="input-container">
                <Label htmlFor="subject" className="input-label">Subject</Label>
                <Input
                  id="subject"
                  name="subject"
                  placeholder="e.g., Question about a feature"
                  value={form.subject}
                  onChange={handleChange}
                  className={errors.subject ? "border-red-500" : ""}
                />
                {errors.subject && (
                  <p className="text-red-500 text-xs mt-1">{errors.subject}</p>
                )}
              </div>

              <div className="input-container">
                <Label htmlFor="name" className="input-label">Your name</Label>
                <Input
                  id="name"
                  name="name"
                  placeholder="John Doe"
                  value={form.name}
                  onChange={handleChange}
                  className={errors.name ? "border-red-500" : ""}
                />
                {errors.name && (
                  <p className="text-red-500 text-xs mt-1">{errors.name}</p>
                )}
              </div>

              <div className="input-container">
                <Label htmlFor="phone" className="input-label">Phone number</Label>
                <Input
                  id="phone"
                  name="phone"
                  type="tel"
                  placeholder="+1 (555) 123-4567"
                  value={form.phone}
                  onChange={handleChange}
                  className={errors.phone ? "border-red-500" : ""}
                />
                {errors.phone && (
                  <p className="text-red-500 text-xs mt-1">{errors.phone}</p>
                )}
              </div>

              <div className="input-container">
                <Label htmlFor="message" className="input-label">Message</Label>
                <Textarea
                  id="message"
                  name="message"
                  placeholder="How can we help you?"
                  value={form.message}
                  onChange={handleChange}
                  className={`rounded-2xl min-h-[120px] ${errors.message ? "border-red-500" : ""}`}
                />
                {errors.message && (
                  <p className="text-red-500 text-xs mt-1">{errors.message}</p>
                )}
              </div>

              <Button 
                type="submit" 
                className="btn-primary w-full flex items-center justify-center"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Sending...
                  </>
                ) : (
                  <>
                    <Send size={18} className="mr-2" />
                    Send Message
                  </>
                )}
              </Button>
            </div>
          </form>
        </div>

        <div className="bg-white shadow-soft rounded-xl p-6">
          <div className="flex items-center mb-6">
            <div className="bg-blue-50 p-3 rounded-full mr-4">
              <Mail size={24} className="text-primary" />
            </div>
            <div>
              <h2 className="font-poppins font-medium">Email us directly</h2>
              <a href="mailto:support@shopsmart.app" className="text-sm text-primary">
                support@shopsmart.app
              </a>
            </div>
          </div>
          
          <div className="text-sm text-neutral-medium">
            <p className="mb-2">Our support team is available:</p>
            <p>Monday - Friday: 9am - 6pm EST</p>
            <p>Saturday: 10am - 4pm EST</p>
            <p>Sunday: Closed</p>
          </div>
        </div>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default ContactUs;
