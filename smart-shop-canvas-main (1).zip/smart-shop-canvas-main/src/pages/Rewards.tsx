
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Award, Calendar, TrendingUp, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import BottomNavigation from "../components/layout/BottomNavigation";

interface RewardsMetric {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
}

const Rewards: React.FC = () => {
  const navigate = useNavigate();
  
  const rewardsData: RewardsMetric[] = [
    {
      title: "Total Savings",
      value: "₹1,245",
      change: 12,
      icon: <Award size={20} className="text-primary" />,
    },
    {
      title: "This Month",
      value: "₹380",
      change: 5,
      icon: <Calendar size={20} className="text-primary" />,
    },
    {
      title: "Reward Points",
      value: "2,430",
      change: 8,
      icon: <TrendingUp size={20} className="text-primary" />,
    },
  ];

  const recentTransactions = [
    { shop: "Reliance Digital", date: "May 10", savings: "₹120", card: "HDFC Visa" },
    { shop: "Café Coffee Day", date: "May 8", savings: "₹45", card: "Amex" },
    { shop: "Big Bazaar", date: "May 5", savings: "₹85", card: "ICICI" },
    { shop: "Myntra", date: "May 3", savings: "₹150", card: "SBI" },
    { shop: "Flipkart", date: "Apr 29", savings: "₹250", card: "Axis" },
  ];

  return (
    <div className="min-h-screen bg-neutral-white pb-20">
      <div className="sticky top-0 z-10 bg-primary shadow-md">
        <div className="pt-12 pb-4 px-6">
          <div className="flex items-center mb-4">
            <button 
              className="mr-3 text-white" 
              onClick={() => navigate(-1)}
            >
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-bold text-white font-poppins">My Rewards</h1>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="grid grid-cols-3 gap-4 mb-8">
          {rewardsData.map((metric, index) => (
            <motion.div
              key={metric.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-xl shadow-soft p-4"
            >
              <div className="flex justify-between items-start mb-2">
                <div className="p-2 rounded-full bg-primary/10">
                  {metric.icon}
                </div>
                {metric.change > 0 && (
                  <Badge className="bg-green-100 text-green-800 text-xs">+{metric.change}%</Badge>
                )}
              </div>
              <p className="text-xs text-neutral-medium mt-2">{metric.title}</p>
              <p className="text-lg font-bold mt-1">{metric.value}</p>
            </motion.div>
          ))}
        </div>
        
        <Card className="mb-6 shadow-soft border-none">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Recent Transactions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentTransactions.map((transaction, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 + 0.3 }}
                  className="flex justify-between items-center py-3 border-b border-neutral-light/20 last:border-0"
                >
                  <div>
                    <p className="font-medium">{transaction.shop}</p>
                    <p className="text-xs text-neutral-medium">{transaction.date}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-green-600">{transaction.savings}</p>
                    <p className="text-xs text-neutral-medium">{transaction.card}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card className="mb-6 shadow-soft border-none">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Monthly Savings Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <p>April 2025</p>
                <p className="font-semibold text-primary">₹650</p>
              </div>
              <div className="flex justify-between items-center">
                <p>March 2025</p>
                <p className="font-semibold text-primary">₹420</p>
              </div>
              <div className="flex justify-between items-center">
                <p>February 2025</p>
                <p className="font-semibold text-primary">₹380</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <div className="bg-primary/5 rounded-2xl p-5 mb-6">
          <h3 className="font-semibold mb-2">Reward Tips</h3>
          <ul className="space-y-2 text-sm">
            <li className="flex items-start">
              <div className="bg-green-100 rounded-full p-1 mr-2 mt-0.5">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              </div>
              Use your HDFC card at Reliance Digital for 5% extra cashback
            </li>
            <li className="flex items-start">
              <div className="bg-green-100 rounded-full p-1 mr-2 mt-0.5">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              </div>
              Link your loyalty cards to maximize points
            </li>
            <li className="flex items-start">
              <div className="bg-green-100 rounded-full p-1 mr-2 mt-0.5">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              </div>
              Pay utility bills with Axis Neo card for 3% cashback
            </li>
          </ul>
        </div>
        
        <p className="text-center text-xs text-neutral-medium mb-8">
          Connect your bank statements for more accurate tracking
        </p>
      </div>

      <BottomNavigation />
    </div>
  );
};

export default Rewards;
