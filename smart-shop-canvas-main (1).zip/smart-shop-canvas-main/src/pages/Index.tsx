
import React, { useState, useEffect } from "react";
import WelcomeScreen from "../components/onboarding/WelcomeScreen";
import RegistrationForm from "../components/onboarding/RegistrationForm";
import VerificationScreen from "../components/onboarding/VerificationScreen";
import LocationPermission from "../components/onboarding/LocationPermission";
import HomeScreen from "../components/home/HomeScreen";
import AppOpeningScreen from "../components/onboarding/AppOpeningScreen";
import { useToast } from "@/hooks/use-toast";

const Index = () => {
  const [onboardingStep, setOnboardingStep] = useState<
    "welcome" | "registration" | "verification" | "location" | "completed"
  >("welcome");
  const [userData, setUserData] = useState({
    phoneNumber: "",
    name: "",
  });
  const [showAppOpening, setShowAppOpening] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    // Check if user has completed onboarding
    const hasCompletedOnboarding = localStorage.getItem("onboardingCompleted");
    if (hasCompletedOnboarding === "true") {
      setOnboardingStep("completed");
      
      // Check if this is the first time opening the app after onboarding
      const hasSeenAppOpening = localStorage.getItem("hasSeenAppOpening");
      if (hasSeenAppOpening !== "true") {
        setShowAppOpening(true);
        // Mark that the user has seen the app opening screen
        localStorage.setItem("hasSeenAppOpening", "true");
      }
    }
  }, []);

  const handleRegistrationSubmit = (phoneNumber: string, name: string) => {
    setUserData({ phoneNumber, name });
    setOnboardingStep("verification");
  };

  const handleVerification = () => {
    setOnboardingStep("location");
    toast({
      title: "Verification successful",
      description: "Your phone number has been verified",
    });
  };

  const handleLocationPermission = () => {
    // In a real app, this would request device location permission
    toast({
      title: "Location access granted",
      description: "You can now find shops near you",
    });
    completeOnboarding();
  };

  const handleSkipLocation = () => {
    toast({
      title: "Location access skipped",
      description: "You can enable this later in settings",
      variant: "destructive",
    });
    completeOnboarding();
  };

  const completeOnboarding = () => {
    // Save user's onboarding status to local storage
    localStorage.setItem("onboardingCompleted", "true");
    localStorage.setItem("userName", userData.name);
    localStorage.setItem("userPhone", userData.phoneNumber);
    setOnboardingStep("completed");
    setShowAppOpening(true);
    // This will be the first time seeing the app opening screen
    localStorage.setItem("hasSeenAppOpening", "true");
  };

  const handleOpeningComplete = () => {
    setShowAppOpening(false);
  };

  // Render different screens based on onboarding step
  const renderOnboardingStep = () => {
    if (onboardingStep === "completed" && showAppOpening) {
      return <AppOpeningScreen onComplete={handleOpeningComplete} />;
    }

    switch (onboardingStep) {
      case "welcome":
        return <WelcomeScreen onContinue={() => setOnboardingStep("registration")} />;
      case "registration":
        return (
          <RegistrationForm
            onSubmit={handleRegistrationSubmit}
            onBack={() => setOnboardingStep("welcome")}
          />
        );
      case "verification":
        return (
          <VerificationScreen
            phoneNumber={userData.phoneNumber}
            onVerify={handleVerification}
            onBack={() => setOnboardingStep("registration")}
          />
        );
      case "location":
        return (
          <LocationPermission
            onAllow={handleLocationPermission}
            onSkip={handleSkipLocation}
          />
        );
      case "completed":
        return <HomeScreen />;
      default:
        return <WelcomeScreen onContinue={() => setOnboardingStep("registration")} />;
    }
  };

  return renderOnboardingStep();
};

export default Index;
