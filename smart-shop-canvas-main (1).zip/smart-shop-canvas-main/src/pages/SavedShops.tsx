
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Clock, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import BottomNavigation from "../components/layout/BottomNavigation";

interface Shop {
  id: string;
  name: string;
  logo: string;
  savingsAmount?: string;
  isPartner?: boolean;
  offerExpiry?: string;
  cardTypes?: string[];
}

const SAVED_SHOPS: Shop[] = [
  {
    id: "s1",
    name: "Reliance Digital",
    logo: "https://logo.clearbit.com/reliancedigital.in",
    savingsAmount: "₹300",
    isPartner: true,
    cardTypes: ["Visa", "Mastercard"],
    offerExpiry: "2 days"
  },
  {
    id: "s4",
    name: "Myntra",
    logo: "https://logo.clearbit.com/myntra.com",
    savingsAmount: "₹400",
    isPartner: true,
    cardTypes: ["Visa", "RuPay"]
  },
  {
    id: "s6",
    name: "Café Coffee Day",
    logo: "https://logo.clearbit.com/cafecoffeeday.com",
    savingsAmount: "₹100",
    isPartner: true,
    cardTypes: ["Visa", "Mastercard"]
  },
  {
    id: "s5",
    name: "Flipkart",
    logo: "https://logo.clearbit.com/flipkart.com",
    savingsAmount: "₹500",
    offerExpiry: "3 days",
    cardTypes: ["Amex", "Mastercard"]
  }
];

const SavedShops: React.FC = () => {
  const navigate = useNavigate();

  const renderEmptyState = () => (
    <div className="px-6 py-8 text-center">
      <div className="bg-neutral-light/20 p-8 rounded-xl">
        <Heart size={40} className="text-neutral-light mx-auto mb-4" />
        <p className="text-neutral-medium">No saved shops yet</p>
        <p className="text-xs text-neutral-medium mt-2">
          Tap the heart icon on any shop to save it
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-neutral-white pb-20">
      <div className="sticky top-0 z-10 bg-primary shadow-md">
        <div className="pt-12 pb-4 px-6">
          <div className="flex items-center mb-4">
            <button 
              className="mr-3 text-white" 
              onClick={() => navigate(-1)}
            >
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-xl font-bold text-white font-poppins">Saved Shops</h1>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        {SAVED_SHOPS.length === 0 ? (
          renderEmptyState()
        ) : (
          <>
            <div className="space-y-4 mb-6">
              {SAVED_SHOPS.map((shop, index) => (
                <motion.div
                  key={shop.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className="overflow-hidden border-none shadow-soft">
                    <CardContent className="p-0">
                      <div className="flex items-center p-4">
                        <div className="bg-neutral-light/10 rounded-xl p-3 mr-4">
                          <img
                            src={shop.logo}
                            alt={shop.name}
                            className="w-12 h-12 object-contain"
                            onError={(e) => {
                              const target = e.target as HTMLImageElement;
                              target.src = `https://ui-avatars.com/api/?name=${shop.name}&background=4A66E4&color=fff`;
                            }}
                          />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-lg">{shop.name}</h4>
                          <div className="flex items-center mt-1">
                            {shop.offerExpiry && (
                              <span className="flex items-center text-xs text-neutral-medium">
                                <Clock size={12} className="mr-1" />
                                Ends in {shop.offerExpiry}
                              </span>
                            )}
                            {shop.isPartner && (
                              <Badge className="bg-primary/10 text-primary text-xs ml-2">
                                Partner
                              </Badge>
                            )}
                          </div>
                          
                          {shop.cardTypes && (
                            <div className="mt-2 flex flex-wrap gap-1">
                              {shop.cardTypes.map(card => (
                                <Badge key={card} variant="outline" className="text-xs px-2">
                                  {card}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </div>
                        {shop.savingsAmount && (
                          <Badge className="bg-primary text-white p-1 px-3">
                            Save {shop.savingsAmount}
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            
            <div className="bg-neutral-light/10 rounded-2xl p-5 mb-8">
              <h3 className="font-semibold mb-3">Shop Highlights</h3>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start">
                  <div className="bg-primary/10 rounded-full p-1 mr-3 mt-0.5">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <span>Flipkart offering additional 10% off for Axis bank cards</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-primary/10 rounded-full p-1 mr-3 mt-0.5">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <span>Myntra sale starts next week - prepare your wishlist</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-primary/10 rounded-full p-1 mr-3 mt-0.5">
                    <div className="w-2 h-2 bg-primary rounded-full"></div>
                  </div>
                  <span>Café Coffee Day's offer expires in 2 days</span>
                </li>
              </ul>
            </div>
          </>
        )}
      </div>

      <BottomNavigation />
    </div>
  );
};

export default SavedShops;
