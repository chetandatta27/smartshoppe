
import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { toast } from "@/components/ui/use-toast";
import CardOfferCarousel from "@/components/shops/CardOfferCarousel";
import ShopHeader from "@/components/shops/ShopHeader";
import ShopHowToUse from "@/components/shops/ShopHowToUse";
import ShopMapActions from "@/components/shops/ShopMapActions";
import ShopAbout from "@/components/shops/ShopAbout";
import ShopCallToAction from "@/components/shops/ShopCallToAction";
import { Shop, CardOffer } from "@/components/shops/ShopTypes";

// Mock data for demo purposes
const mockShops: Shop[] = [
  {
    id: "shop1",
    name: "Reliance Digital",
    logo: "https://logos-world.net/wp-content/uploads/2022/01/Reliance-Digital-Logo.png",
    isPartner: true,
    distance: "500m",
    offerExpiry: "3 days",
    cardTypes: ["Visa", "Mastercard", "RuPay"],
    savingsAmount: "₹300",
    address: "123 Main Street, Mumbai",
    location: { lat: 19.076, lng: 72.8777 },
  },
  {
    id: "shop2",
    name: "Big Bazaar",
    logo: "https://logo.clearbit.com/bigbazaar.com",
    isPartner: false,
    distance: "1.2km",
    offerExpiry: "5 days",
    cardTypes: ["Visa", "RuPay"],
    savingsAmount: "₹200",
    address: "45 Market Avenue, Delhi",
    location: { lat: 28.7041, lng: 77.1025 },
  },
  {
    id: "shop3",
    name: "Café Coffee Day",
    logo: "https://logo.clearbit.com/cafecoffeeday.com",
    isPartner: true,
    distance: "350m",
    offerExpiry: "1 day",
    cardTypes: ["Visa", "Mastercard"],
    savingsAmount: "₹100",
    address: "78 Coffee Boulevard, Bangalore",
    location: { lat: 12.9716, lng: 77.5946 },
  }
];

const mockCardOffers: CardOffer[] = [
  {
    id: "card1",
    bank: "HDFC Bank",
    network: "Visa",
    cashback: "10%",
    color: "#FF5733",
    badge: "Top Pick",
    offerDetails: "Get 10% cashback on all purchases",
    minSpend: "₹500",
    cashbackCap: "₹200",
    processingTime: "3-5 days",
  },
  {
    id: "card2",
    bank: "SBI Card",
    network: "Mastercard",
    cashback: "5X Points",
    color: "#33FF57",
    offerDetails: "Earn 5X reward points on shopping",
    minSpend: "₹1000",
    cashbackCap: "No limit",
    processingTime: "7 days",
  },
  {
    id: "card3",
    bank: "ICICI Bank",
    network: "RuPay",
    cashback: "₹150 Off",
    color: "#3357FF",
    offerDetails: "Flat ₹150 off on purchases above ₹1500",
    minSpend: "₹1500",
    cashbackCap: "₹150",
    processingTime: "Instant",
  },
];

const ShopDetail: React.FC = () => {
  const { shopId } = useParams<{ shopId: string }>();
  const navigate = useNavigate();
  const [isSaved, setIsSaved] = useState(false);
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  
  // Find the shop based on shopId
  const shop = mockShops.find(s => s.id === shopId) || mockShops[0];
  const cardOffers = mockCardOffers;
  
  const handleSaveShop = () => {
    setIsSaved(!isSaved);
    toast({
      title: isSaved ? "Shop removed" : "Shop saved",
      description: isSaved 
        ? "This shop has been removed from your saved shops" 
        : "This shop has been added to your saved shops",
      variant: isSaved ? "destructive" : "default",
    });
  };
  
  const handleCardSelect = (cardId: string) => {
    setSelectedCard(cardId);
  };
  
  const handleUseCard = () => {
    if (selectedCard) {
      toast({
        title: "Offer activated!",
        description: "We'll track your cashback for this purchase",
        variant: "default",
      });
    } else {
      toast({
        title: "Please select a card",
        description: "Select a card to use for this offer",
        variant: "destructive",
      });
    }
  };
  
  const handleViewMap = () => {
    // In a real app, this would navigate to a map view
    if (shop.location) {
      navigate(`/map?lat=${shop.location.lat}&lng=${shop.location.lng}&shopName=${shop.name}`);
    }
  };
  
  const handleGetDirections = () => {
    // Open Google Maps with directions to this location
    if (shop.location) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${shop.location.lat},${shop.location.lng}&destination_place_id=${shop.name}`;
      window.open(url, "_blank");
    }
  };

  // Calculate expiry date for countdown
  const expiryDate = new Date();
  if (shop.offerExpiry) {
    expiryDate.setDate(expiryDate.getDate() + parseInt(shop.offerExpiry));
  }

  return (
    <div className="min-h-screen bg-neutral-white pb-20">
      <ShopHeader
        shopId={shop.id}
        name={shop.name}
        logo={shop.logo}
        distance={shop.distance}
        offerExpiry={shop.offerExpiry}
        cardTypes={shop.cardTypes}
        isSaved={isSaved}
        onSaveToggle={handleSaveShop}
      />
      
      <div className="px-6 py-4">
        {/* Card Offers Section */}
        <div className="mb-6">
          <h2 className="text-lg font-bold mb-3 font-poppins">Top Cards to Use at This Shop</h2>
          <CardOfferCarousel 
            cards={cardOffers} 
            onCardSelect={handleCardSelect} 
            selectedCardId={selectedCard} 
          />
        </div>
        
        <ShopHowToUse 
          selectedCard={selectedCard} 
          cardOffers={cardOffers} 
          expiryDate={expiryDate} 
        />
        
        <ShopMapActions 
          location={shop.location} 
          name={shop.name}
          onViewMap={handleViewMap} 
          onGetDirections={handleGetDirections} 
        />
        
        <ShopAbout 
          name={shop.name} 
          isPartner={shop.isPartner} 
          address={shop.address}
        />
        
        <ShopCallToAction onUseCard={handleUseCard} />
      </div>
    </div>
  );
};

export default ShopDetail;
